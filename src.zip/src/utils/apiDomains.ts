export const apiDomainConfig: Record<string, Record<string, string>> = {
  "192.168.1.126": {
    base: "http://192.168.1.126:81",
    fam: "http://192.168.1.126:82",
    main: "http://192.168.1.126:83",
    bg: "http://192.168.1.126:84",
    party: "http://192.168.1.126:89",
    inventory: "http://192.168.1.126:201",
    purchase: "http://192.168.1.126:86",
    warehouse: "http://192.168.1.126:202",
  },

  "192.168.1.130": {
    base: "http://192.168.1.130:81",
    fam: "http://192.168.1.130:82",
    main: "http://192.168.1.130:83",
    bg: "http://192.168.1.130:84",
    party: "http://192.168.1.130:89",
    inventory: "http://192.168.1.130:201",
    purchase: "http://192.168.1.130:86",
    warehouse: "http://192.168.1.130:202",
  },

  "192.168.1.135": {
    base: "http://192.168.1.135:81",
    fam: "http://192.168.1.135:82",
    main: "http://192.168.1.135:83",
    bg: "http://192.168.1.135:84",
    party: "http://192.168.1.135:89",
    inventory: "http://192.168.1.135:201",
    purchase: "http://192.168.1.135:86",
  },

  "bsoft.bannarimill.com": {
    base: "http://bsoft.bannarimill.com:81",
    fam: "http://bsoft.bannarimill.com:82",
    main: "http://bsoft.bannarimill.com:83",
    bg: "http://bsoft.bannarimill.com:84",
    party: "http://bsoft.bannarimill.com:89",
    inventory: "http://bsoft.bannarimill.com:201",
    purchase: "http://bsoft.bannarimill.com:86",
  },

  localhost: {
    base: "http://192.168.1.126:81",
    fam: "http://192.168.1.126:82",
    main: "http://192.168.1.126:83",
    bg: "http://192.168.1.126:84",
    party: "http://192.168.1.126:89",
    inventory: "http://192.168.1.126:201",
    purchase: "http://192.168.1.126:86",
    warehouse: "http://192.168.1.126:202",
  },
};
