"use client";
import React from "react";
import ApprovalRulePage from "../../../../components/organisms/Workflow/Master/ApprovalRulePage";
import ApprovalDetail from "../../../../components/organisms/Workflow/Master/ApprovalDetailPage";

function page() {
  return (
    <div>
      <ApprovalDetail />
    </div>
  );
}

export default page;
