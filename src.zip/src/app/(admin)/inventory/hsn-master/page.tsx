"use client";

import React from "react";
import HsnMasterPage from "../../../../components/organisms/Purchase/HsnMasterPage";

function page() {
  return (
    <div>
      <HsnMasterPage />
    </div>
  );
}

export default page;
