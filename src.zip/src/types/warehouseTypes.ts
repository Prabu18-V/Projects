import type { ReactNode } from "react";
import type { SxProps, Theme } from "@mui/material/styles";

export type WarehouseFormMode = "create" | "edit";
export type Option = { id: number; label: string };
export type Props = { warehouseId?: string };

export interface WarehouseFormValues {
  warehouseCode: string;
  warehouseName: string;
  unitId: number | null;
  unitName?: string;
  parentWarehouseGroupId: number | null;
  parentWarehouseGroupName?: string;
  isGroup: boolean;
  isVirtualWarehouse: boolean;
  warehouseTypeId: number | null;
  storageTypeId: number | null;
  areaTypeId: number | null;
  operationTypeId: number | null;
  contactPersonName: string;
  mobileNumber: string;
  email: string;
  addressLine1: string;
  addressLine2: string;
  cityId: number | null;
  stateId: number | null;
  countryId: number | null;
  pincode: string;
  status: boolean;
  isScrapWarehouse: boolean;
  isTransitWarehouse: boolean;
  maxCapacity: string;
  capacityUomId: number | null;
  accountId: number | null;
  accountName?: string;
  defaultForStockEntry: boolean;
  allowedItemGroupIds: number[];
}

export interface WarehouseFormProps {
  initial?: Partial<WarehouseFormValues>;
  onSubmit?: (values: WarehouseFormValues) => void;
}

export interface ToggleTileProps {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  subtitle?: string;
  icon: ReactNode;
  disabled?: boolean;
}

export interface SectionCardProps {
  icon?: ReactNode;
  title: string;
  action?: ReactNode;
  children: ReactNode;
  sx?: SxProps<Theme>;
  titleColor?: string;

}

export type FieldKind =
  | "text"
  | "number"
  | "autocomplete"
  | "autocomplete-multi"
  | "pincode"
  | "unit-readonly"
  | "toggle";



export type FieldDef = {
  section: "general" | "contact" | "address" | "capacity" | "itemgroups" | "settings";
  label: string;
  name:
  | "warehouseName"
  | "unitId"
  | "parentWarehouseGroupId"
  | "parentWarehouseGroupName"
  | "isGroup"
  | "isVirtualWarehouse"
  | "warehouseTypeId"
  | "storageTypeId"
  | "areaTypeId"
  | "operationTypeId"
  | "contactPersonName"
  | "mobileNumber"
  | "email"
  | "addressLine1"
  | "addressLine2"
  | "cityId"
  | "stateId"
  | "countryId"
  | "pincode"
  | "isScrapWarehouse"
  | "isTransitWarehouse"
  | "maxCapacity"
  | "capacityUomId"
  | "accountId"
  | "accountName"
  | "defaultForStockEntry"
  | "allowedItemGroupIds"
  | "isActive";
  kind: FieldKind;
  isRequired?: boolean;
  size: { xs: number; sm: number; md: number; lg: number };
  optionsKey?: keyof AutocompleteSources;
  disableErrorText?: boolean;
  maxLength?: number;
  min?: number;
  max?: number;
  subtitle?: string;
  icon?: ReactNode;
};
export type AutocompleteSources = {
  warehouseTypes: Option[];
  storageTypes: Option[];
  areaTypes: Option[];
  operationTypes: Option[];
  capacityUoms: Option[];
  itemGroups: Option[];
  parentWHOptions: Option[];
  countryData: any[];
  stateData: any[];
  cityData: any[];
};






export type Id = number;
export type BinStatus = 'Active' | 'Blocked' | 'Inactive';
export interface DropdownOption {
  id: Id;
  code: string;
  description?: string | null;
}
export interface WarehouseOption extends DropdownOption {
  isActive?: boolean;
}
export interface RackOption extends DropdownOption {
  warehouseId: Id;
  floorId?: Id | null;
  aisleId?: Id | null;
  rackLevelId?: Id | null;
}

export interface UomOption extends DropdownOption { }
export interface ApiListResponse<T> {
  statusCode: number;
  message?: string;
  data: T[];
  totalCount: number;
  errors?: string[];
}

export interface ApiItemResponse<T> {
  statusCode: number;
  message?: string;
  data: T;
  errors?: string[];
}

export interface BinRow {
  id: Id;
  warehouseId: Id;
  warehouseCode: string;
  rackId?: Id | null;
  rackCode?: string | null;
  binCode: string;
  binName?: string | null;
  capacity: number;
  capacityUomId: Id;
  capacityUomCode: string;
  status: BinStatus;
  createdBy?: string;
  createdDate?: string;
  modifiedBy?: string | null;
  modifiedDate?: string | null;
}

export interface BinForm {
  id: Id;
  warehouseId: Id | '';
  warehouseCode?: string;
  rackId: Id | '' | null;
  rackCode?: string | null;
  binCode?: string;
  binName: string;
  capacity: number | '';
  capacityUomId: Id | '';
  status: BinStatus;
  isActive?: boolean;
}

export type BinErrorField =
  | 'warehouseId'
  | 'rackId'
  | 'binName'
  | 'capacity'
  | 'capacityUomId'
  | 'status';

export interface CreateBinProps {
  open: boolean;
  close: () => void;
  editFlag: boolean;
  form: BinForm;
  errorFields: BinErrorField[];
  onChange: (name: keyof BinForm, value: any) => void;
  onSubmit: () => void;
  warehouses: WarehouseOption[];
  racks: RackOption[];
  uoms: UomOption[];
  statusOptions: BinStatus[];
  submitDisabled?: boolean;
}









export interface DropdownOption1 {
  id: Id;
  code?: string;
  name?: string;
  description?: string | null;
  isActive?: boolean;
}

export interface WarehouseOption extends DropdownOption { }
export interface FloorOption extends DropdownOption {
  warehouseId?: Id;
}
export interface AisleOption extends DropdownOption {
  warehouseId?: Id;
  floorId?: Id;
}export interface RackLevelOption extends DropdownOption {
  warehouseId?: Id;
  floorId?: Id;
  aisleId?: Id;
}

export interface UomOption extends DropdownOption { }
export interface RackRow {
  id: Id;
  warehouseId: Id;
  warehouseCode: string;
  rackCode: string;
  rackName: string;
  floorId: Id;
  floorCode: string;
  aisleId: Id;
  aisleCode: string;
  rackLevelId: Id;
  rackLevelCode: string;
  maxCapacity: number;
  capacityUomId: Id;
  capacityUomCode: string;
  rackWidth?: string | null;
  rackHeight?: string | null;
  dimensionUomId?: Id | null;
  dimensionUomCode?: string | null;
  isActive: boolean;
  createdBy?: string;
  createdDate?: string;
  modifiedBy?: string | null;
  modifiedDate?: string | null;
}

export interface RackForm {
  id: Id;
  warehouseId: Id | '';
  rackCode?: string;
  rackName: string;
  floorId: Id | '';
  aisleId: Id | '';
  rackLevelId: Id | '';
  maxCapacity: number | '';
  capacityUomId: Id | '';
  rackWidth?: string;
  rackHeight?: string;
  dimensionUomId?: Id | '';
  isActive: boolean;
}

export type RackErrorField =
  | 'warehouseId'
  | 'rackName'
  | 'floorId'
  | 'aisleId'
  | 'rackLevelId'
  | 'maxCapacity'
  | 'capacityUomId';

export interface ApiListResponse<T> {
  statusCode: number;
  message?: string;
  data: T[];
  totalCount: number;
  errors?: string[];
}

export interface ApiItemResponse<T> {
  statusCode: number;
  message?: string;
  data: T;
  errors?: string[];
}

export interface CreateRackProps {
  open: boolean;
  close: () => void;
  editFlag: boolean;
  form: RackForm;
  errorFields: RackErrorField[];
  onChange: (name: keyof RackForm, value: any) => void;
  onSubmit: () => void;
  warehouses: WarehouseOption[];
  floors: FloorOption[];
  aisles: AisleOption[];
  rackLevels: RackLevelOption[];
  uoms: UomOption[];
  submitDisabled?: boolean;
}
