"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Box } from "@mui/material";
import IconBreadcrumbs from "../../../molecules/AdminLayout/BreadCrumbs";
import GlobalSearch from "../../../molecules/AdminLayout/GlobalSearch";
import { MuiButton, MuiTable } from "bsoft-base-elements";
import { GoPlus } from "react-icons/go";
import NoDataFound from "../../../molecules/AdminLayout/NoDataFound";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin6Line } from "react-icons/ri";
import SkeletonLoader from "../../../molecules/AdminLayout/SkeletonLoader";
import ErrorModal from "../../../molecules/Master/Role/ErrorModal";
import toast from "react-hot-toast";
import { usePrivilegeCheck } from "../../../../hooks/usePrivilegeCheck";
import { useDebounce } from "../../../../hooks/useDebounceHook";
import { useDataFetchHook } from "../../../../hooks/useDataFetchHook";
import { Apirequest } from "../../../../utils/lib";
import DeleteConfirmation from "../../../molecules/Master/DeleteConfirmation";
import CreateBinMaster from "../../../molecules/Warehouse/BinMaster/CreateBinMaster";
import {
    ApiItemResponse,
    ApiListResponse,
    BinErrorField,
    BinForm,
    BinRow,
    BinStatus,
    RackOption,
    UomOption,
    WarehouseOption,
} from "../../../../types/warehouseTypes";
import WarehouseConfig from "../../../../utils/warehouse.api.json";

const toForm = (): BinForm => ({
    id: 0,
    warehouseId: '',
    warehouseCode: '',
    rackId: null,
    rackCode: '',
    binCode: '',
    binName: '',
    capacity: '',
    capacityUomId: '',
    status: 'Active',
});

const normalize = <T,>(src: any): T[] =>
    Array.isArray(src) ? src : Array.isArray(src?.data) ? src.data : [];

function BinListPage() {
    const [pathname, setPathName] = useState<string>("");
    const permissions = usePrivilegeCheck(pathname);
    useEffect(() => {
        const currentPath = window.location.pathname.split("/bsoft").at(-1) || "";
        setPathName(currentPath);
    }, []);
    const [rows, setRows] = useState<BinRow[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [count, setCount] = useState<number>(0);
    const [page, setPage] = useState<number>(1);
    const [size, setSize] = useState<number>(15);
    const [search, setSearch] = useState<string>("");
    const debouncedSearchTerm = useDebounce(search, 500);
    const [open, setOpen] = useState<boolean>(false);
    const [editFlag, setEditFlag] = useState<boolean>(false);
    const [form, setForm] = useState<BinForm>(toForm());
    const originalRef = useRef<BinForm>(toForm());
    const [errorFields, setErrorFields] = useState<BinErrorField[]>([]);
    const [editId, setEditId] = useState<number | null>(null);
    const [deleteOpen, setDeleteOpen] = useState(false);
    const [deleteId, setDeleteId] = useState<number | null>(null);
    const [errorModalOpen, setErrorModalOpen] = useState(false);
    const [errorMessages, setErrorMessages] = useState<string[]>([]);

    // const { data: warehouseData } = useDataFetchHook(
    //     WarehouseConfig.Warehouse.WarehouseList.endpoint, 
    //     WarehouseConfig.Warehouse.WarehouseList.method,
    //     "inventory"
    // );

    // const { data: rackData } = useDataFetchHook(
    //     WarehouseConfig.RackMaster.RackList.endpoint, 
    //     WarehouseConfig.RackMaster.RackList.method,
    //     "inventory"
    // );

    const { data: uomData } = useDataFetchHook(
        WarehouseConfig.WarehouseMisc.endpoint.replace("{type}", "UOM"),
        WarehouseConfig.WarehouseMisc.method,
        "inventory"
    );
    const warehouseData = [
        { id: 1, name: 'Warehouse 1' },
        { id: 2, name: 'Warehouse 2' },
        { id: 3, name: 'Warehouse 3' },
    ];

    const rackData = [
        { id: 1, name: 'Rack 1', warehouseId: 1 },
        { id: 2, name: 'Rack 2', warehouseId: 1 },
        { id: 3, name: 'Rack 3', warehouseId: 2 },
    ];
    const warehouses: WarehouseOption[] = normalize<WarehouseOption>(warehouseData);
    const racks: RackOption[] = normalize<RackOption>(rackData);
    const uoms: UomOption[] = normalize<UomOption>(uomData);

    const statusOptions: BinStatus[] = ['Active', 'Blocked', 'Inactive'];

    // columns
    const columns = useMemo(
        () => [
            {
                field: "s_no",
                headerName: "S.No",
                minWidth: 60,
                flex: 1,
                sortable: false,
                renderCell: (params: any) => {
                    const idx = params.api.getRowIndexRelativeToVisibleRows(params.id);
                    return (page - 1) * size + (idx + 1);
                },
            },
            { field: "warehouseCode", headerName: "Warehouse", minWidth: 140, flex: 1 },
            { field: "rackCode", headerName: "Rack", minWidth: 120, flex: 1 },
            { field: "binCode", headerName: "Bin Code", minWidth: 140, flex: 1.2 },
            { field: "binName", headerName: "Bin Name", minWidth: 160, flex: 1.2 },
            {
                field: "capacity",
                headerName: "Capacity",
                minWidth: 120,
                flex: 0.8,
            },
            {
                field: "capacityUomCode",
                headerName: "UOM",
                minWidth: 120,
                flex: 0.8,
            },
            {
                field: "status",
                headerName: "Status",
                minWidth: 120,
                flex: 1,
            },
            {
                field: "actions",
                headerName: "Actions",
                minWidth: 140,
                flex: 1,
                sortable: false,
                filterable: false,
                renderCell: (params: any) => (
                    <Box display="flex" alignItems="center" gap={2} height="100%">
                        <FiEdit
                            fontSize={20}
                            color="black"
                            cursor="pointer"
                            onClick={() => handleEdit(params.row)}
                        />
                        <RiDeleteBin6Line
                            fontSize={20}
                            color="red"
                            cursor="pointer"
                            onClick={() => requestDelete(params.row.id)}
                        />
                    </Box>
                ),
            },
        ],
        [page, size, permissions]
    );

    const fetchList = async () => {
        try {
            setLoading(true);
            const url = WarehouseConfig.Warehouse.GetAllWarehouseMaster.endpoint
                .replace("{page}", String(page))
                .replace("{size}", String(size))
                .replace("{search}", encodeURIComponent(debouncedSearchTerm || ""));

            const res: ApiListResponse<BinRow> = await Apirequest(
                url,
                WarehouseConfig.Warehouse.GetAllWarehouseMaster.method,
                null,
                "inventory"
            ).then((r) => r.data);

            const { statusCode, data, totalCount } = res ?? ({} as any);
            if (statusCode === 200 || statusCode === 201) {
                setRows(Array.isArray(data) ? data : []);
                setCount(Number(totalCount) || 0);
            } else {
                setRows([]);
                setCount(0);
            }
        } catch (err) {
            console.error("Bin list error:", err);
            setRows([]);
            setCount(0);
        } finally {
            setLoading(false);
        }
    };

    const getBinById = async (id: number) => {
        const cfg = WarehouseConfig.Warehouse.GetWarehouseMasterid as {
            endpoint: string;
            method: string;
        };
        const url = cfg.endpoint.replace("{id}", String(id));
        const res: ApiItemResponse<BinRow> = await Apirequest(url, cfg.method, null, "inventory").then((r) => r.data);
        return res?.data;
    };

    const createBin = async (payload: Partial<BinForm>) => {
        const cfg = WarehouseConfig.Warehouse.AddWarehouseMaster as {
            endpoint: string;
            method: string;
        };
        return Apirequest(cfg.endpoint, cfg.method, payload, "inventory").then((r) => r.data);
    };

    const updateBin = async (id: number, payload: Partial<BinForm>) => {
        const cfg = WarehouseConfig.Warehouse.UpdateWarehouseMaster as {
            endpoint: string;
            method: string;
        };
        const url = cfg.endpoint.replace("{id}", String(id));
        return Apirequest(url, cfg.method, payload, "inventory").then((r) => r.data);
    };

    const deleteBin = async (id: number) => {
        const cfg = WarehouseConfig.Warehouse.DeleteWarehouseMaster as {
            endpoint: string;
            method: string;
        };
        const url = cfg.endpoint.replace("{id}", String(id));
        return Apirequest(url, cfg.method, null, "inventory").then((r) => r.data);
    };

    useEffect(() => {
        fetchList();
    }, [debouncedSearchTerm, page, size]);
    const handleClickOpen = () => {
        setEditFlag(false);
        setEditId(null);
        const blank = toForm();
        setForm(blank);
        originalRef.current = blank;
        setErrorFields([]);
        setOpen(true);
    };

    const handleEdit = async (row: BinRow) => {
        try {
            setEditFlag(true);
            setEditId(row.id);
            setOpen(true);

            const data = await getBinById(row.id);
            const filled: BinForm = {
                id: data?.id ?? row.id,
                warehouseId: data?.warehouseId ?? row.warehouseId,
                warehouseCode: data?.warehouseCode ?? row.warehouseCode,
                rackId: data?.rackId ?? row.rackId ?? null,
                rackCode: data?.rackCode ?? row.rackCode ?? "",
                binCode: data?.binCode ?? row.binCode ?? "",
                binName: data?.binName ?? row.binName ?? "",
                capacity: data?.capacity ?? row.capacity ?? "",
                capacityUomId: data?.capacityUomId ?? row.capacityUomId,
                status: (data?.status ?? row.status) as BinStatus,
            };

            setForm(filled);
            originalRef.current = filled;
            setErrorFields([]);
        } catch (e) {
            console.error("Edit load error:", e);
            toast.error("Failed to load bin details");
        }
    };

    const handleClose = () => {
        setOpen(false);
        setErrorFields([]);
    };

    const requestDelete = (id: number) => {
        setDeleteId(id);
        setDeleteOpen(true);
    };

    const handleConfirmDelete = async () => {
        if (deleteId == null) return;
        try {
            const response = await deleteBin(deleteId);
            if (response?.statusCode === 200 || response?.statusCode === 201) {
                toast.success(response?.message ?? "Deleted");
                await fetchList();
            } else {
                toast.error(response?.message ?? "Delete failed");
                if (Array.isArray(response?.errors) && response.errors.length > 0) {
                    setErrorModalOpen(true);
                    setErrorMessages(response.errors);
                }
            }
        } catch (err) {
            console.error("Delete error:", err);
            toast.error("Something went wrong");
        } finally {
            setDeleteOpen(false);
            setDeleteId(null);
        }
    };

    const onFieldChange = (name: keyof BinForm, value: any) => {
        if (name === "capacity") {
            if (value === "") {
                setForm((p) => ({ ...p, capacity: "" }));
            } else {
                const n = Number(value);
                if (Number.isNaN(n)) return;
                setForm((p) => ({ ...p, capacity: n }));
            }
            return;
        }

        if (name === "warehouseId" || name === "capacityUomId" || name === "rackId") {
            if (value === "" || value === null) {
                setForm((p) => ({ ...p, [name]: value }));
            } else {
                const n = Number(value);
                if (Number.isNaN(n)) return;
                setForm((p) => ({ ...p, [name]: n as any }));
            }
            return;
        }

        setForm((p) => ({ ...p, [name]: value }));
    };

    // Validation per acceptance criteria
    const isValid = React.useMemo(() => {
        const errs: BinErrorField[] = [];
        if (!form.warehouseId || Number(form.warehouseId) <= 0) errs.push("warehouseId");
        if (form.capacity === "" || Number(form.capacity) <= 0) errs.push("capacity");
        if (!form.capacityUomId || Number(form.capacityUomId) <= 0) errs.push("capacityUomId");
        if (!form.status) errs.push("status");
        if (form.binName && form.binName.length > 50) {
            setForm((p) => ({ ...p, binName: p.binName.slice(0, 50) }));
        }
        setErrorFields(errs);
        return errs.length === 0;
    }, [form]);

    const isDirty = useMemo(
        () => JSON.stringify(form) !== JSON.stringify(originalRef.current),
        [form]
    );

    const submitDisabled = editFlag ? !isDirty : false;

    const onSubmit = async () => {
        if (!isValid) return;
        const payload: Partial<BinForm> = {
            id: Number(form.id || 0),
            warehouseId: Number(form.warehouseId),
            rackId: form.rackId === "" ? null : (form.rackId as number | null),
            binName: form.binName?.trim() || "",
            capacity: Number(form.capacity || 0),
            capacityUomId: Number(form.capacityUomId),
            status: form.status as BinStatus,
        };
        try {
            const resp =
                editFlag && editId
                    ? await updateBin(editId, payload)
                    : await createBin(payload);

            if (resp?.statusCode === 200 || resp?.statusCode === 201) {
                toast.success(
                    resp?.message ?? (editFlag ? "Updated successfully" : "Bin created successfully")
                );
                setOpen(false);
                setEditFlag(false);
                setForm(toForm());
                originalRef.current = toForm();
                await fetchList();
            } else {
                toast.error(resp?.message ?? "Request failed");
                if (Array.isArray(resp?.errors) && resp.errors.length > 0) {
                    setErrorModalOpen(true);
                    setErrorMessages(resp.errors);
                }
            }
        } catch (err) {
            console.error("Submit error:", err);
            toast.error("Something went wrong");
        }
    };
    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        setPage(1);
        setSearch(e.target.value);
    };

    return (
        <>
            <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                flexWrap="wrap"
                gap={2}
                mt={1}
            >
                <Box>
                    <IconBreadcrumbs parent="Warehouse" child="Bin" path="" />
                </Box>

                <Box display="flex" alignItems="center" gap={2} flexWrap="wrap">
                    <GlobalSearch
                        placeholder="Search Bin"
                        width={220}
                        onChange={handleSearch}
                    />
                    <MuiButton
                        startIcon={<GoPlus />}
                        variant="contained"
                        onClick={handleClickOpen}
                    >
                        Create
                    </MuiButton>
                </Box>
            </Box>

            <Box sx={{ width: "100%", my: 2, height: 700 }} className="main-table">
                {loading ? (
                    <SkeletonLoader />
                ) : (
                    <MuiTable
                        rows={rows}
                        columns={columns}
                        getRowId={(row) => row.id}
                        paginationMode="server"
                        initialState={{
                            pagination: { paginationModel: { pageSize: size } },
                        }}
                        rowCount={count}
                        rowHeight={40}
                        pageSizeOptions={[15, 30, 50]}
                        disableRowSelectionOnClick
                        slots={{ noRowsOverlay: () => <NoDataFound /> }}
                        onPaginationModelChange={(model: any) => {
                            setPage(model.page + 1);
                            setSize(model.pageSize);
                        }}
                    />
                )}
            </Box>

            <ErrorModal
                open={errorModalOpen}
                onClose={() => setErrorModalOpen(false)}
                errors={errorMessages}
            />
            <DeleteConfirmation
                open={deleteOpen}
                close={() => setDeleteOpen(false)}
                handleDelete={handleConfirmDelete}
            />

            <CreateBinMaster
                open={open}
                close={handleClose}
                editFlag={editFlag}
                form={form}
                errorFields={errorFields}
                onChange={onFieldChange}
                onSubmit={onSubmit}
                warehouses={warehouses}
                racks={racks}
                uoms={uoms}
                statusOptions={statusOptions}
                submitDisabled={submitDisabled}
            />
        </>
    );
}

export default BinListPage;
