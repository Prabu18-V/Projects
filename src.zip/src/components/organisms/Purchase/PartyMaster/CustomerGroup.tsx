import React from "react";
import { FieldConfig } from "./GeneralPartyInfo";
import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  TextField,
  useTheme,
  Typography,
  Button,
  IconButton,
  Divider,
  Grid2,
} from "@mui/material";
import { StyledAutocomplete } from "../../../../utils/lib";
import { MdAdd } from "react-icons/md";
import { RiDeleteBin6Line } from "react-icons/ri";

const paymentOptions = ["Cash", "Online", "Cheque"];

const customerGroupFields: FieldConfig[] = [
  {
    name: "modeOfPayment",
    label: "Mode of Payment",
    field: "dropdown",
    options: paymentOptions,
  },
  {
    name: "preferredCurrencyForPurchase",
    label: "Preferred Currency for Purchase",
    field: "input",
  },
  {
    name: "creditDays",
    label: "Credit Days",
    field: "input",
  },
  {
    name: "dueDate",
    label: "Due Date Based On",
    field: "dropdown",
    options: ["Invoice Date", "Delivery Date"],
  },
  {
    name: "leadTime",
    label: "Lead Time",
    field: "input",
  },
  {
    name: "preferredCurrencyForSale",
    label: "Preferred Currency for Sale",
    field: "input",
  },
  {
    name: "creditLimit",
    label: "Credit Limit",
    field: "input",
  },
  {
    name: "priceList",
    label: "Price List (Selling)",
    field: "input",
  },
  {
    name: "customerType",
    label: "Customer Type",
    field: "dropdown",
    options: ["Individual", "Company", "Distributor"],
  },
  {
    name: "isInternalSupplier",
    label: "Is Internal Supplier",
    field: "checkbox",
  },
  {
    name: "isInternalCustomer",
    label: "Is Internal Customer",
    field: "checkbox",
  },
  {
    name: "stopPayments",
    label: "Stop Payments",
    field: "checkbox",
  },
];

const bankDetailsFields: FieldConfig[] = [
  {
    name: "bankAccountNumber",
    label: "Bank Account Number",
    isRequired: true,
    field: "input",
  },
  { name: "bankName", label: "Bank Name", isRequired: true, field: "input" },
  { name: "bankBranch", label: "Bank Branch", field: "input" },
  { name: "ifscCode", label: "IFSC Code", isRequired: true, field: "input" },
  { name: "swiftCode", label: "SWIFT Code", field: "input" },
  {
    name: "accountType",
    label: "Account Type",
    field: "dropdown",
    options: ["Savings", "Current"],
  },
];

const bankCheckboxFields: FieldConfig[] = [
  { name: "isDefaultAccount", label: "Is Default Account", field: "checkbox" },
  { name: "isPrimaryAccount", label: "Is Primary Account", field: "checkbox" },
];

type BankSection = {
  id: string;
  bankAccountNumber: string;
  bankName: string;
  bankBranch: string;
  ifscCode: string;
  swiftCode: string;
  accountType: string;
  isDefaultAccount: boolean;
  isPrimaryAccount: boolean;
};

interface CustomerGroupProps {
  formData: Record<string, any>;
  handleInputChange: (name: string, value: any) => void;
  bankSections: BankSection[];
  onBankSectionsChange: (sections: BankSection[]) => void;
}

function CustomerGroup({
  formData,
  handleInputChange,
  bankSections,
  onBankSectionsChange,
}: CustomerGroupProps) {
  const theme = useTheme();

  const canAddSecondBank = bankSections.length < 2;

  const addBankSection = () => {
    if (bankSections.length < 2) {
      const newBank: BankSection = {
        id: `bank-${Date.now()}`,
        bankAccountNumber: "",
        bankName: "",
        bankBranch: "",
        ifscCode: "",
        swiftCode: "",
        accountType: "",
        isDefaultAccount: false,
        isPrimaryAccount: false,
      };
      onBankSectionsChange([...bankSections, newBank]);
    }
  };

  const removeBankSection = (id: string) => {
    if (bankSections.length > 1) {
      onBankSectionsChange(bankSections.filter((section) => section.id !== id));
    }
  };

  const updateBankSection = (id: string, field: string, value: any) => {
    onBankSectionsChange(
      bankSections.map((section) =>
        section.id === id ? { ...section, [field]: value } : section
      )
    );
  };

  const renderField = (
    { name, label, type, isRequired, field = "input", options }: FieldConfig,
    value: any,
    onChange: (value: any) => void
  ) => (
    <Grid2 size={{ xs: 12, sm: 6 }} key={name}>
      {field === "input" && (
        <FormControl fullWidth>
          <Typography
            variant="body2"
            sx={{
              mb: 1,
              fontWeight: 500,
              color: theme.palette.text.primary,
            }}
          >
            {label}
            {isRequired && (
              <Typography
                component="span"
                sx={{ fontSize: "initial !important" }}
                color="error.main"
              >
                *
              </Typography>
            )}
          </Typography>
          <TextField
            fullWidth
            type={type}
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            sx={{
              "& .MuiOutlinedInput-root": {
                height: "40px",
                fontSize: "0.875rem",
              },
            }}
          />
        </FormControl>
      )}
      {field === "dropdown" && (
        <FormControl fullWidth>
          <Typography
            variant="body2"
            sx={{
              mb: 1,
              fontWeight: 500,
              color: theme.palette.text.primary,
            }}
          >
            {label}
            {isRequired && (
              <Typography
                component="span"
                sx={{ fontSize: "initial !important" }}
                color="error.main"
              >
                *
              </Typography>
            )}
          </Typography>
          <StyledAutocomplete
            options={options || []}
            value={value || null}
            onChange={(event, newValue) => onChange(newValue)}
            renderInput={(params) => (
              <TextField
                {...params}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    height: "40px",
                    fontSize: "0.875rem",
                  },
                }}
              />
            )}
          />
        </FormControl>
      )}
      {field === "checkbox" && (
        <FormControlLabel
          control={
            <Checkbox
              checked={value || false}
              onChange={(e) => onChange(e.target.checked)}
              size="medium"
            />
          }
          label={
            <Typography
              variant="body2"
              sx={{
                fontWeight: 500,
                color: theme.palette.text.primary,
              }}
            >
              {label}
            </Typography>
          }
        />
      )}
    </Grid2>
  );

  const renderFields = (fields: FieldConfig[]) => (
    <Grid2 container spacing={2}>
      {fields.map((fieldConfig) => (
        <React.Fragment key={fieldConfig.name}>
          {renderField(fieldConfig, formData[fieldConfig.name], (value) =>
            handleInputChange(fieldConfig.name, value)
          )}
        </React.Fragment>
      ))}
    </Grid2>
  );

  const renderBankSection = (bank: BankSection, index: number) => (
    <Box key={bank.id}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1,
          mb: 2,
        }}
      >
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          Bank Account {index + 1}
        </Typography>
        {bank.isPrimaryAccount && (
          <Typography
            variant="caption"
            sx={{
              bgcolor: "primary.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.75rem",
            }}
          >
            (Primary)
          </Typography>
        )}
        {!bank.isPrimaryAccount && index === 1 && (
          <Typography
            variant="caption"
            sx={{
              bgcolor: "secondary.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.75rem",
            }}
          >
            (Secondary)
          </Typography>
        )}
        {bank.isDefaultAccount && (
          <Typography
            variant="caption"
            sx={{
              bgcolor: "success.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.75rem",
            }}
          >
            (Default)
          </Typography>
        )}
        {bankSections.length > 1 && (
          <IconButton
            onClick={() => removeBankSection(bank.id)}
            size="small"
            sx={{ color: "error.main" }}
          >
            <RiDeleteBin6Line />
          </IconButton>
        )}
      </Box>
      <Grid2 container spacing={2}>
        {bankCheckboxFields.map((field) => (
          <React.Fragment key={field.name}>
            {renderField(
              field,
              bank[field.name as keyof BankSection],
              (value) => updateBankSection(bank.id, field.name, value)
            )}
          </React.Fragment>
        ))}
        {bankDetailsFields.map((field) => (
          <React.Fragment key={field.name}>
            {renderField(
              field,
              bank[field.name as keyof BankSection],
              (value) => updateBankSection(bank.id, field.name, value)
            )}
          </React.Fragment>
        ))}
      </Grid2>
      {index < bankSections.length - 1 && <Divider sx={{ my: 3 }} />}
    </Box>
  );

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
          Payment Preferences
        </Typography>
        {renderFields(customerGroupFields)}
      </Box>

      <Box p={2} bgcolor={"#fafafa"}>
        <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
          Bank Details
        </Typography>
        {bankSections.map((bank, index) => renderBankSection(bank, index))}
        {canAddSecondBank && (
          <Button
            variant="outlined"
            startIcon={<MdAdd />}
            onClick={addBankSection}
            sx={{
              mt: 2,
              borderColor: theme.palette.primary.main,
              color: theme.palette.primary.main,
              "&:hover": {
                backgroundColor: theme.palette.primary.light,
                borderColor: theme.palette.primary.main,
                color: "#fff",
                borderRadius: 1,
              },
            }}
          >
            Add Second Bank Account
          </Button>
        )}
      </Box>
    </Box>
  );
}

export default CustomerGroup;
