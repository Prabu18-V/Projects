import * as React from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import NavTabs from "../../../atoms/ModernComponents/NavTabs";
import { TabContext, TabPanel } from "@mui/lab";
import GeneralPartyInfo from "./GeneralPartyInfo";
import CustomerGroup from "./CustomerGroup";
import { Box } from "@mui/material";
import UploadDocuments from "./UploadDocuments";
import TaxCompliance from "./TaxCompliance";
import PurchaseConfig from "../../../../utils/purchase.api.json";
import toast from "react-hot-toast";
import axios from "axios";
import { Apirequest } from "../../../../utils/lib";
import { useDataFetchHook } from "../../../../hooks/useDataFetchHook";

export const tabStyles = {
  width: "100%",
  mt: 2,
  p: 0,
  "& .MuiAccordionSummary-content": {
    alignItems: "center",
    margin: "0 !important",
    gap: 1.5,
  },
  "& .MuiAccordionSummary-root": {
    minHeight: "56px",
    "&.Mui-expanded": {
      minHeight: "56px",
    },
  },
  "& .MuiAccordionDetails-root": {
    paddingTop: 0,
  },
  "& .MuiButtonBase-root": {
    borderRadius: 0,
    border: "none",
  },
};

interface ContactSection {
  id: string;
  firstName: string;
  lastName: string;
  gender: string;
  designation: string;
  emailId: string;
  mobileNo: string;
  phone: string;
  preferredCommunicationChannel: string;
  contactType: string;
  isPrimaryContact: boolean;
  isBillingContact: boolean;
  isShippingContact: boolean;
}

interface AddressSection {
  id: string;
  addressType: string;
  primaryAddress: boolean;
  isShippingAddress: boolean;
  isBillingAddress: boolean;
  addressLine1: string;
  addressLine2: string;
  pincode: string;
  country: string;
  state: string;
  city: string;
  gstState: string;
  gstStateCode: string;
}

interface BankSection {
  id: string;
  bankAccountNumber: string;
  bankName: string;
  bankBranch: string;
  ifscCode: string;
  swiftCode: string;
  accountType: string;
  isDefaultAccount: boolean;
  isPrimaryAccount: boolean;
}

interface PartyState {
  formData: Record<string, any>;
  contactSections: ContactSection[];
  addressSections: AddressSection[];
  bankSections: BankSection[];
  expandedAccordion: string | false;
  partyType: any[];
  partyGroup: any[];
}

export default function PartyTabs() {
  const [value, setValue] = React.useState("1");
  const [isLoadingLocation, setIsLoadingLocation] = React.useState(false);
  const [isLoadingGst, setIsLoadingGst] = React.useState(false);
  const [regFlag, setRegFlag] = React.useState(false);
  const [partyState, setPartyState] = React.useState<PartyState>({
    formData: {},
    partyType: [],
    partyGroup: [],
    contactSections: [
      {
        id: "contact-1",
        firstName: "",
        lastName: "",
        gender: "",
        designation: "",
        emailId: "",
        mobileNo: "",
        phone: "",
        preferredCommunicationChannel: "",
        contactType: "",
        isPrimaryContact: true,
        isBillingContact: false,
        isShippingContact: false,
      },
    ],
    addressSections: [
      {
        id: "address-1",
        addressType: "",
        primaryAddress: false,
        isShippingAddress: false,
        isBillingAddress: false,
        addressLine1: "",
        addressLine2: "",
        pincode: "",
        country: "",
        state: "",
        city: "",
        gstState: "",
        gstStateCode: "",
      },
    ],
    bankSections: [
      {
        id: "bank-1",
        bankAccountNumber: "",
        bankName: "",
        bankBranch: "",
        ifscCode: "",
        swiftCode: "",
        accountType: "",
        isDefaultAccount: false,
        isPrimaryAccount: true,
      },
    ],
    expandedAccordion: "panel1",
  });

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const handleInputChange = (name: string, value: any) => {
    if (name === "registrationType") {
      if (
        typeof value?.code === "string" &&
        value?.code?.toLowerCase()?.includes("un-registered")
      ) {
        setRegFlag(true);
      } else setRegFlag(false);
    }
    setPartyState((prev) => ({
      ...prev,
      formData: { ...prev.formData, [name]: value },
    }));
  };

  const updateContactSections = (contactSections: ContactSection[]) => {
    setPartyState((prev) => ({ ...prev, contactSections }));
  };

  const updateAddressSections = (addressSections: AddressSection[]) => {
    setPartyState((prev) => ({ ...prev, addressSections }));
  };

  const updateBankSections = (bankSections: BankSection[]) => {
    setPartyState((prev) => ({ ...prev, bankSections }));
  };

  const updateExpandedAccordion = (expandedAccordion: string | false) => {
    setPartyState((prev) => ({ ...prev, expandedAccordion }));
  };

  const GetPostalCode = async (pincode: string) => {
    try {
      if (!pincode || pincode.length !== 6) return null;

      const response = await axios
        .get(`https://api.postalpincode.in/pincode/${pincode}`)
        .then((res) => res.data[0])
        .then((res) => res?.PostOffice?.[0]);
      if (!response) {
        toast.error("No records found");
        setIsLoadingLocation(false);
      }
      return response;
    } catch (err) {
      console.log("Error fetching postal data:", err);
      return null;
    }
  };

  const handlePincodeChange = async (
    sectionId: string,
    pincode: string,
    sectionType: "address"
  ) => {
    if (sectionType === "address") {
      const updatedSections = partyState.addressSections.map((section) =>
        section.id === sectionId ? { ...section, pincode } : section
      );
      updateAddressSections(updatedSections);
    }

    if (pincode && pincode.length === 6) {
      setIsLoadingLocation(true);
      const locationData = await GetPostalCode(pincode);

      if (locationData && sectionType === "address") {
        const updatedSections = partyState.addressSections.map((section) =>
          section.id === sectionId
            ? {
              ...section,
              country: locationData.Country || "",
              state: locationData.State || "",
              city: locationData.District || "",
              gstState: locationData.State || "",
              pincode: pincode,
            }
            : section
        );
        updateAddressSections(updatedSections);
        setIsLoadingLocation(false);
      }
    } else {
      const updatedSections = partyState.addressSections.map((section) =>
        section.id === sectionId
          ? {
            ...section,
            country: "",
            state: "",
            city: "",
            gstState: "",
            pincode: pincode,
          }
          : section
      );
      updateAddressSections(updatedSections);
      setIsLoadingLocation(false);
    }
  };

  const clearGstRelatedData = () => {
    const clearedAddressSections = partyState.addressSections.map(
      (address, index) =>
        index === 0
          ? {
            ...address,
            addressLine1: "",
            addressLine2: "",
            pincode: "",
            country: "",
            state: "",
            city: "",
            gstState: "",
            gstStateCode: "",
          }
          : address
    );
    setPartyState((prevState) => ({
      ...prevState,
      formData: {
        ...prevState.formData,
        legalName: "",
        pan: "",
        gstStateCode: "",
      },
      addressSections: clearedAddressSections,
    }));
  };

  const GetGstDetails = async (gst: string) => {
    const { endpoint, method } = PurchaseConfig.CommonApi.GstInfo;
    setIsLoadingGst(true);
    try {
      const response = await Apirequest(
        endpoint.replace("{gst}", gst.toString()),
        method,
        null,
        "party"
      ).then((res) => res.data);
      const { statusCode, data, message } = response;
      if (statusCode === 200 || statusCode === 201) {
        setIsLoadingGst(false);
        const pincode = data?.addrPncd || "";
        const updatedAddressSections = partyState.addressSections.map(
          (address, index) =>
            index === 0
              ? {
                ...address,
                addressLine1: `${data?.addrBno}, ${data?.addrSt}` || "",
                addressLine2: data?.addrLoc || "",
                pincode: pincode,
              }
              : address
        );
        toast.success(message);
        setPartyState({
          ...partyState,
          formData: {
            ...partyState.formData,
            legalName: data?.legalName,
            gstStateCode: data?.stateCode,
            pan: gst?.substring(2, 12),
          },
          addressSections: updatedAddressSections,
        });

        if (pincode && pincode.length === 6) {
          setIsLoadingLocation(true);
          const locationData = await GetPostalCode(pincode);

          if (locationData) {
            const finalUpdatedAddressSections = partyState.addressSections.map(
              (address, index) =>
                index === 0
                  ? {
                    ...address,
                    addressLine1: `${data?.addrBno}, ${data?.addrSt}` || "",
                    addressLine2: data?.addrLoc || "",
                    pincode: pincode,
                    country: locationData.Country || "",
                    state: locationData.State || "",
                    city: locationData.District || "",
                    gstState: locationData.State || "",
                  }
                  : address
            );

            setPartyState((prevState) => ({
              ...prevState,
              formData: { ...prevState.formData, legalName: data?.legalName },
              addressSections: finalUpdatedAddressSections,
            }));
          }
          setIsLoadingLocation(false);
        }
      } else {
        setIsLoadingGst(false);
        toast.error(message || "GST details not found");
        clearGstRelatedData();
      }
    } catch (err) {
      console.log(err);
      setIsLoadingGst(false);
      toast.error("Error fetching GST details");
      clearGstRelatedData();
    }
  };

  React.useEffect(() => {
    const GstNumber = partyState.formData?.gstNumber ?? "";

    if (GstNumber && GstNumber.length < 15 && GstNumber.length > 0) {
      clearGstRelatedData();
    }

    if (GstNumber && GstNumber.length === 15) {
      GetGstDetails(GstNumber);
    }

    if (!GstNumber) {
      clearGstRelatedData();
    }
  }, [partyState.formData?.gstNumber]);

  // ---------------- Dropdown API Calls ----------------

  const { data: RegistrationTypes } = useDataFetchHook(
    PurchaseConfig.PurchaseMisc.endpoint.replace("{type}", "REGISTRATION TYPE"),
    PurchaseConfig.PurchaseMisc.method,
    "party"
  );

  const { data: GroupType } = useDataFetchHook(
    PurchaseConfig.PurchaseMisc.endpoint.replace("{type}", "GROUPTYPE"),
    PurchaseConfig.PurchaseMisc.method,
    "party"
  );

  return (
    <NavTabs>
      <TabContext value={value}>
        <Tabs
          value={value}
          onChange={handleChange}
          textColor="primary"
          indicatorColor="primary"
          aria-label="primary tabs example"
        >
          <Tab value="1" label="Details" />
          <Tab value="2" label="Tax & Compliance Details" />
          <Tab value="3" label="Payment Preferences" />
          <Tab value="4" label="Upload Documents" />
        </Tabs>

        <TabPanel value="1">
          <Box sx={tabStyles}>
            <GeneralPartyInfo
              formData={partyState.formData}
              handleInputChange={handleInputChange}
              contactSections={partyState.contactSections}
              addressSections={partyState.addressSections}
              expandedAccordion={partyState.expandedAccordion}
              onContactSectionsChange={updateContactSections}
              onAddressSectionsChange={updateAddressSections}
              onExpandedAccordionChange={updateExpandedAccordion}
              handlePincodeChange={handlePincodeChange}
              isLoadingLocation={isLoadingLocation}
              isLoadingGst={isLoadingGst}
              RegistrationTypes={RegistrationTypes}
              GroupType={GroupType}
              regFlag={regFlag}
            />
          </Box>
        </TabPanel>

        <TabPanel value="2">
          <Box sx={tabStyles}>
            <TaxCompliance
              formData={partyState.formData}
              handleInputChange={handleInputChange}
            />
          </Box>
        </TabPanel>

        <TabPanel value="3">
          <Box sx={tabStyles}>
            <CustomerGroup
              formData={partyState.formData}
              handleInputChange={handleInputChange}
              bankSections={partyState.bankSections}
              onBankSectionsChange={updateBankSections}
            />
          </Box>
        </TabPanel>

        <TabPanel value="4">
          <Box sx={tabStyles}>
            <UploadDocuments />
          </Box>
        </TabPanel>
      </TabContext>
    </NavTabs>
  );
}
