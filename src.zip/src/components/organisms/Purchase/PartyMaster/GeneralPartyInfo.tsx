"use client";

import React from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Box,
  Grid,
  useTheme,
  Button,
  Checkbox,
  FormControlLabel,
  FormControl,
  Divider,
  IconButton,
  InputAdornment,
  CircularProgress,
  TextField,
} from "@mui/material";
import { FaCirclePlus } from "react-icons/fa6";
import { FaMinusCircle } from "react-icons/fa";
import { MdAdd } from "react-icons/md";
import { RiDeleteBin6Line } from "react-icons/ri";
import { StyledAutocomplete } from "../../../../utils/lib";
import { MuiText } from "bsoft-base-elements";
import CustomTextField from "../../../atoms/ModernComponents/CustomTextField";

interface GeneralPartyInfoProps {
  formData: Record<string, any>;
  handleInputChange: (name: string, value: any) => void;
  contactSections: ContactSection[];
  addressSections: AddressSection[];
  expandedAccordion: string | false;
  onContactSectionsChange: (sections: ContactSection[]) => void;
  onAddressSectionsChange: (sections: AddressSection[]) => void;
  onExpandedAccordionChange: (expanded: string | false) => void;
  handlePincodeChange: (
    sectionId: string,
    pincode: string,
    sectionType: "address"
  ) => void;
  isLoadingLocation: boolean;
  isLoadingGst: boolean;
  regFlag: boolean;
  RegistrationTypes: any[];
  GroupType: any[];
}

export type FieldConfig = {
  name: string;
  label: string;
  type?: string;
  isRequired?: boolean;
  field?: "input" | "dropdown" | "switch" | "image" | "checkbox" | "picker";
  options?: any;
  isDisable?: boolean;
  multiple?: boolean;
  optionLabel?: any[];
};

type ContactSection = {
  id: string;
  firstName: string;
  lastName: string;
  gender: string;
  designation: string;
  emailId: string;
  mobileNo: string;
  phone: string;
  preferredCommunicationChannel: string;
  contactType: string;
  isPrimaryContact: boolean;
  isBillingContact: boolean;
  isShippingContact: boolean;
};

type AddressSection = {
  id: string;
  addressType: string;
  primaryAddress: boolean;
  isShippingAddress: boolean;
  isBillingAddress: boolean;
  addressLine1: string;
  addressLine2: string;
  pincode: string;
  country: string;
  state: string;
  city: string;
  gstState: string;
  gstStateCode: string;
};

const partyTypeOptions = ["Supplier", "Customer", "Agent", "Transporter"];
const partyGroupOptions = ["Cotton Suppliers", "Yarn Customers", "Transporter"];
const genderOptions = ["Male", "Female", "Others"];
const prefferedCommunication = ["Whatsapp", "Email", "SMS", "Telegram"];
const registartionOption = [
  "Company",
  "Individual",
  "Partnership",
  "Un-Registered",
];

const contactInfoFields: FieldConfig[] = [
  { name: "firstName", label: "First Name", isRequired: true, field: "input" },
  { name: "lastName", label: "Last Name", field: "input" },
  {
    name: "gender",
    label: "Gender",
    field: "dropdown",
    options: genderOptions,
  },
  { name: "designation", label: "Designation", field: "input" },
  { name: "emailId", label: "Email ID", type: "email", field: "input" },
  {
    name: "mobileNo",
    label: "Mobile No",
    type: "tel",
    isRequired: true,
    field: "input",
  },
  { name: "phone", label: "Phone", type: "tel", field: "input" },
  {
    name: "preferredCommunicationChannel",
    label: "Preferred Communication Channel",
    field: "dropdown",
    options: prefferedCommunication,
  },
  {
    name: "contactType",
    label: "Contact Type",
    field: "dropdown",
    options: ["Personal", "Business"],
  },
];

const addressFields: FieldConfig[] = [
  {
    name: "addressLine1",
    label: "Address Line 1",
    type: "text",
    field: "input",
  },
  {
    name: "addressLine2",
    label: "Address Line 2",
    type: "text",
    field: "input",
  },
  { name: "pincode", label: "Pincode", field: "input" },
  { name: "country", label: "Country", field: "input" },
  { name: "state", label: "State", field: "input" },
  { name: "city", label: "City", field: "input" },
];

const addressCheckboxFields: FieldConfig[] = [
  { name: "primaryAddress", label: "Primary Address", field: "checkbox" },
  {
    name: "isShippingAddress",
    label: "Is Shipping Address",
    field: "checkbox",
  },
  { name: "isBillingAddress", label: "Is Billing Address", field: "checkbox" },
];

function GeneralPartyInfo({
  formData,
  handleInputChange,
  contactSections,
  addressSections,
  expandedAccordion,
  onContactSectionsChange,
  onAddressSectionsChange,
  onExpandedAccordionChange,
  handlePincodeChange,
  isLoadingLocation,
  isLoadingGst,
  GroupType,
  RegistrationTypes,
  regFlag,
}: GeneralPartyInfoProps) {
  const theme = useTheme();

  const partyDetailsFields: FieldConfig[] = [
    {
      name: "registrationType",
      label: "Registration Type",
      isRequired: true,
      field: "dropdown",
      options: RegistrationTypes ?? [],
    },
    {
      name: "legalName",
      label: "Legal Name",
      isRequired: true,
      isDisable: regFlag ? false : true,
      field: "input",
    },
    {
      name: "partyType",
      label: "Party Type",
      isRequired: true,
      field: "dropdown",
      options: GroupType ?? [],
      multiple: true,
    },
    { name: "gstNumber", label: "GST Number", field: "input" },
    {
      name: "partyGroup",
      label: "Party Group",
      isRequired: true,
      field: "dropdown",
      options: partyGroupOptions,
      multiple: true,
    },
    {
      name: "gstStateCode",
      label: "GST State Code",
      field: "input",
      isDisable: true,
    },
    {
      name: "pan",
      label: "PAN",
      field: "input",
      isDisable: true,
    },
  ];

  const needsBillingContact = !contactSections.some(
    (contact) => contact.isBillingContact
  );
  const needsShippingContact = !contactSections.some(
    (contact) => contact.isShippingContact
  );
  const needsBillingAddress = !addressSections.some(
    (address) => address.isBillingAddress
  );
  const needsShippingAddress = !addressSections.some(
    (address) => address.isShippingAddress
  );

  const addContactSection = (type: "billing" | "shipping" | "secondary") => {
    const newContact: ContactSection = {
      id: `contact-${Date.now()}`,
      firstName: "",
      lastName: "",
      gender: "",
      designation: "",
      emailId: "",
      mobileNo: "",
      phone: "",
      preferredCommunicationChannel: "",
      contactType: "",
      isPrimaryContact: type === "secondary" ? false : false,
      isBillingContact: type === "billing",
      isShippingContact: type === "shipping",
    };
    onContactSectionsChange([...contactSections, newContact]);
  };

  const addAddressSection = (type: "billing" | "shipping") => {
    const newAddress: AddressSection = {
      id: `address-${Date.now()}`,
      addressType: "",
      primaryAddress: false,
      isShippingAddress: type === "shipping",
      isBillingAddress: type === "billing",
      addressLine1: "",
      addressLine2: "",
      pincode: "",
      country: "",
      state: "",
      city: "",
      gstState: "",
      gstStateCode: "",
    };
    onAddressSectionsChange([...addressSections, newAddress]);
  };

  const removeContactSection = (id: string) => {
    if (contactSections.length > 1) {
      onContactSectionsChange(
        contactSections.filter((section) => section.id !== id)
      );
    }
  };

  const removeAddressSection = (id: string) => {
    if (addressSections.length > 1) {
      onAddressSectionsChange(
        addressSections.filter((section) => section.id !== id)
      );
    }
  };

  const updateContactSection = (id: string, field: string, value: any) => {
    onContactSectionsChange(
      contactSections.map((section) =>
        section.id === id ? { ...section, [field]: value } : section
      )
    );
  };

  const updateAddressSection = (id: string, field: string, value: any) => {
    onAddressSectionsChange(
      addressSections.map((section) =>
        section.id === id ? { ...section, [field]: value } : section
      )
    );
  };

  const renderField = (
    {
      name,
      label,
      type,
      isRequired,
      field = "input",
      options,
      isDisable,
      multiple,
    }: FieldConfig,
    value: any,
    onChange: (value: any) => void,
    disabled: boolean = false
  ) => (
    <Grid item xs={12} sm={6} md={4} key={name}>
      {field === "input" && (
        <FormControl fullWidth>
          <MuiText
            variant="body2"
            sx={{
              mb: 1,
              fontWeight: 500,
              color: theme.palette.text.primary,
            }}
          >
            {label}
            {isRequired && (
              <MuiText
                component="span"
                color="error.main"
                sx={{ fontSize: "unset !important" }}
              >
                *
              </MuiText>
            )}
          </MuiText>
          <CustomTextField
            fullWidth
            type={type}
            value={value || ""}
            disabled={isDisable || disabled}
            onChange={onChange}
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    {([
                      "country",
                      "state",
                      "city",
                      "gstState",
                      "gstNumber",
                    ].includes(label.toLowerCase()) &&
                      isLoadingLocation) ||
                      (isLoadingGst && <CircularProgress size={16} />)}
                  </InputAdornment>
                ),
              },
            }}
          />
        </FormControl>
      )}
      {field === "dropdown" && (
        <FormControl fullWidth>
          <MuiText
            variant="body2"
            sx={{
              mb: 1,
              fontWeight: 500,
              color: theme.palette.text.primary,
            }}
          >
            {label}
            {isRequired && (
              <MuiText
                component="span"
                color="error.main"
                sx={{ fontSize: "unset !important" }}
              >
                *
              </MuiText>
            )}
          </MuiText>
          <StyledAutocomplete
            multiple={multiple || false}
            options={options}
            size="small"
            className="styledAutocomplete"
            disableCloseOnSelect={multiple}
            value={multiple ? value || [] : value}
            onChange={(event, newValue) => onChange(newValue)}
            getOptionLabel={(option: any) => option?.description || ""}
            isOptionEqualToValue={(option: any, value: any) =>
              option.id === value.id
            }
            renderOption={(props, option: any) => (
              <li {...props} key={option?.id}>
                <div style={{ fontSize: 14 }}>
                  <span style={{ fontWeight: 550 }}>{option?.code}</span> -{" "}
                  <small>{option?.description}</small>
                  <br />
                </div>
              </li>
            )}
            renderInput={(params) => <TextField {...params} />}
            disabled={disabled || isDisable}
          />
        </FormControl>
      )}
      {field === "checkbox" && (
        <FormControlLabel
          control={
            <Checkbox
              checked={value || false || name.includes("primaryAddress")}
              onChange={(e) => onChange(e.target.checked)}
              size="medium"
            />
          }
          label={
            <MuiText
              variant="body2"
              sx={{
                fontWeight: 500,
                color: theme.palette.text.primary,
              }}
            >
              {label}
            </MuiText>
          }
        />
      )}
    </Grid>
  );

  const renderFields = (fields: FieldConfig[]) => (
    <Grid container spacing={2}>
      {fields.map((fieldConfig) =>
        renderField(
          fieldConfig,
          formData[fieldConfig.name],
          (value) => handleInputChange(fieldConfig.name, value),
          false
        )
      )}
    </Grid>
  );

  const renderContactSection = (contact: ContactSection, index: number) => (
    <Box key={contact.id}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1,
          mb: 2,
        }}
      >
        <MuiText sx={{ fontWeight: 550 }}>Contact {index + 1}</MuiText>
        {contact.isPrimaryContact && (
          <MuiText
            variant="caption"
            sx={{
              bgcolor: "primary.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.65rem",
            }}
          >
            (Primary)
          </MuiText>
        )}
        {!contact.isPrimaryContact && index === 1 && (
          <MuiText
            variant="caption"
            sx={{
              bgcolor: "secondary.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.65rem",
            }}
          >
            (Secondary)
          </MuiText>
        )}
        {contact.isBillingContact && (
          <MuiText
            variant="caption"
            sx={{
              bgcolor: "info.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.65rem",
            }}
          >
            (Billing)
          </MuiText>
        )}
        {contact.isShippingContact && (
          <MuiText
            variant="caption"
            sx={{
              bgcolor: "warning.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.65rem",
            }}
          >
            (Shipping)
          </MuiText>
        )}
        {contactSections.length > 1 && (
          <IconButton
            onClick={() => removeContactSection(contact.id)}
            size="small"
            sx={{ color: "error.main" }}
          >
            <RiDeleteBin6Line />
          </IconButton>
        )}
      </Box>
      <Grid container spacing={2}>
        {contactInfoFields.map((field) =>
          renderField(
            field,
            contact[field.name as keyof ContactSection],
            (value) => updateContactSection(contact.id, field.name, value),
            false
          )
        )}
      </Grid>
      {index < contactSections.length - 1 && <Divider sx={{ my: 3 }} />}
    </Box>
  );

  const renderAddressSection = (address: AddressSection, index: number) => (
    <Box key={address.id}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1,
          mb: 2,
        }}
      >
        <MuiText sx={{ fontWeight: 600 }}>Address {index + 1}</MuiText>
        {address.isBillingAddress && (
          <MuiText
            variant="caption"
            sx={{
              bgcolor: "primary.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.75rem",
            }}
          >
            (Billing)
          </MuiText>
        )}
        {address.isShippingAddress && (
          <MuiText
            variant="caption"
            sx={{
              bgcolor: "secondary.main",
              color: "white",
              px: 1,
              py: 0.25,
              borderRadius: 1,
              fontSize: "0.75rem",
            }}
          >
            (Shipping)
          </MuiText>
        )}
        {addressSections.length > 1 && (
          <IconButton
            onClick={() => removeAddressSection(address.id)}
            size="small"
            sx={{ color: "error.main" }}
          >
            <RiDeleteBin6Line />
          </IconButton>
        )}
      </Box>
      <Grid container spacing={2}>
        {addressCheckboxFields.map((field) =>
          renderField(
            field,
            address[field.name as keyof AddressSection],
            (value) => updateAddressSection(address.id, field.name, value),
            false
          )
        )}
        {addressFields.map((field) => {
          const shouldDisableField = index === 0;
          return field.name === "pincode" ? (
            <Grid item xs={12} sm={6} md={4} key={field.name}>
              <FormControl fullWidth>
                <MuiText
                  variant="body2"
                  sx={{
                    mb: 1,
                    fontWeight: 500,
                    color: theme.palette.text.primary,
                  }}
                >
                  {field.label}
                  {field.isRequired && (
                    <MuiText
                      component="span"
                      color="error.main"
                      sx={{ fontSize: "unset !important" }}
                    >
                      *
                    </MuiText>
                  )}
                </MuiText>
                <CustomTextField
                  fullWidth
                  disabled={index === 0}
                  value={address.pincode || ""}
                  onChange={(newvalue) => {
                    const newPincode = newvalue;
                    if (/^\d{0,6}$/.test(newPincode)) {
                      handlePincodeChange(address.id, newPincode, "address");
                    }
                  }}
                />
              </FormControl>
            </Grid>
          ) : (
            renderField(
              field,
              address[field.name as keyof AddressSection],
              (value) => updateAddressSection(address.id, field.name, value),
              shouldDisableField
            )
          );
        })}
      </Grid>
      {index < addressSections.length - 1 && <Divider sx={{ my: 3 }} />}
    </Box>
  );

  const accordionSx = (panelKey: string) => ({
    borderRadius: 2,
    border: "1px solid #e0e0e0",
    backgroundColor: "#fafafa",
    boxShadow:
      expandedAccordion === panelKey ? "0 4px 12px rgba(0,0,0,0.05)" : "none",
    borderLeft:
      expandedAccordion === panelKey
        ? `4px solid ${theme.palette.primary.main}`
        : "4px solid #e0e0e0",
    transition: "all 0.3s ease-in-out",
    "&:before": { display: "none" },
    mb: 2,
  });

  return (
    <Box>
      <Accordion
        expanded={expandedAccordion === "panel1"}
        onChange={(event, isExp) =>
          onExpandedAccordionChange(isExp ? "panel1" : false)
        }
        sx={accordionSx("panel1")}
        elevation={0}
        defaultExpanded
      >
        <AccordionSummary>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            {expandedAccordion === "panel1" ? (
              <FaMinusCircle color="#38b5c6" />
            ) : (
              <FaCirclePlus color="#38b5c6" />
            )}
            <MuiText sx={{ fontWeight: 600 }}>Party Details</MuiText>
          </Box>
        </AccordionSummary>
        <AccordionDetails>{renderFields(partyDetailsFields)}</AccordionDetails>
      </Accordion>

      <Accordion
        expanded={expandedAccordion === "panel2"}
        onChange={(event, isExp) =>
          onExpandedAccordionChange(isExp ? "panel2" : false)
        }
        sx={accordionSx("panel2")}
        elevation={0}
      >
        <AccordionSummary>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            {expandedAccordion === "panel2" ? (
              <FaMinusCircle color="#38b5c6" />
            ) : (
              <FaCirclePlus color="#38b5c6" />
            )}
            <MuiText sx={{ fontWeight: 600 }}>Contact Details</MuiText>
          </Box>
        </AccordionSummary>
        <AccordionDetails>
          {contactSections.map((contact, index) =>
            renderContactSection(contact, index)
          )}

          {/* Add Secondary Contact Button */}
          {contactSections.length < 2 && (
            <Box sx={{ mt: 2 }}>
              <Button
                variant="outlined"
                startIcon={<MdAdd />}
                onClick={() => addContactSection("secondary")}
                sx={{
                  borderColor: theme.palette.secondary.main,
                  color: theme.palette.secondary.main,
                  "&:hover": {
                    backgroundColor: theme.palette.secondary.light,
                    borderColor: theme.palette.secondary.main,
                    color: "#fff",
                    borderRadius: 1,
                  },
                }}
              >
                Add Secondary Contact
              </Button>
            </Box>
          )}
        </AccordionDetails>
      </Accordion>

      <Accordion
        expanded={expandedAccordion === "panel3"}
        onChange={(event, isExp) =>
          onExpandedAccordionChange(isExp ? "panel3" : false)
        }
        sx={accordionSx("panel3")}
        elevation={0}
      >
        <AccordionSummary>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            {expandedAccordion === "panel3" ? (
              <FaMinusCircle color="#38b5c6" />
            ) : (
              <FaCirclePlus color="#38b5c6" />
            )}
            <MuiText sx={{ fontWeight: 600 }}>Address Details</MuiText>
          </Box>
        </AccordionSummary>
        <AccordionDetails>
          {addressSections.map((address, index) =>
            renderAddressSection(address, index)
          )}
          <Box mt={2}>
            {needsBillingAddress && (
              <Button
                variant="outlined"
                startIcon={<MdAdd />}
                onClick={() => addAddressSection("billing")}
                sx={{
                  borderColor: theme.palette.primary.main,
                  color: theme.palette.primary.main,
                  "&:hover": {
                    backgroundColor: theme.palette.primary.light,
                    borderColor: theme.palette.primary.main,
                    color: "#fff",
                    borderRadius: 1,
                  },
                }}
              >
                Add Billing Address
              </Button>
            )}
            {needsShippingAddress && (
              <Button
                variant="outlined"
                startIcon={<MdAdd />}
                onClick={() => addAddressSection("shipping")}
                sx={{
                  borderColor: theme.palette.secondary.main,
                  color: theme.palette.secondary.main,
                  ml: 1,
                  "&:hover": {
                    backgroundColor: theme.palette.secondary.light,
                    borderColor: theme.palette.secondary.main,
                    color: "#fff",
                    borderRadius: 1,
                  },
                }}
              >
                Add Shipping Address
              </Button>
            )}
          </Box>
        </AccordionDetails>
      </Accordion>
    </Box>
  );
}

export default GeneralPartyInfo;
