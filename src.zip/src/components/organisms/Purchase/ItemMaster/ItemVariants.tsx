"use client";

import React, { useState } from "react";
import { Box, Grid, FormControl, TextField, useTheme } from "@mui/material";
import { MuiText, MuiButton } from "bsoft-base-elements";
import CustomAutocomplete from "../../../atoms/ModernComponents/CustomAutocomplete";

interface SupplierRow {
  attributes: string;
  value: string;
}

const ItemVariants = ({ VariantMisc }: { VariantMisc: any }) => {
  const theme = useTheme();

  const [supplierForm, setSupplierForm] = useState<SupplierRow>({
    attributes: "",
    value: "",
  });
  const [suppliers, setSuppliers] = useState<SupplierRow[]>([]);

  const variantFields = [
    {
      key: "attributes",
      label: "Attributes",
      type: "autocomplete",
      options: [{ label: "Color" }, { label: "Size" }],
    },
    {
      key: "value",
      label: "Value",
      type: "text",
    },
  ];

  const handleSupplierFormChange = (key: keyof SupplierRow, value: string) => {
    setSupplierForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSupplierAdd = () => {
    if (supplierForm.attributes && supplierForm.value) {
      setSuppliers([...suppliers, supplierForm]);
      setSupplierForm({ attributes: "", value: "" });
    }
  };

  const renderField = (field: any, value: any, onChange: any) => {
    switch (field.type) {
      case "autocomplete":
        return (
          <CustomAutocomplete
            disablePortal
            options={field.options || []}
            value={
              value
                ? field.options.find((opt: any) => opt.label === value) || null
                : null
            }
            onChange={(_, val: any) => onChange(val ? val.label : "")}
          />
        );
      case "text":
        return (
          <TextField
            fullWidth
            variant="outlined"
            size="small"
            sx={{
              "& .MuiOutlinedInput-root": {
                height: "40px",
                fontSize: "0.875rem",
                background: "#fff",
              },
            }}
            value={value}
            onChange={(e) => onChange(e.target.value)}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Box>
      <Grid container spacing={2} alignItems="flex-end" mb={2}>
        <Grid item xs={12} sm={6} md={3}>
          <FormControl fullWidth>
            <MuiText
              variant="body2"
              sx={{
                mb: 1,
                fontWeight: 500,
                color: theme.palette.text.primary,
                fontSize: "0.875rem",
              }}
            >
              Variant Based On
            </MuiText>
            <CustomAutocomplete
              disablePortal
              options={[{ label: "Size" }, { label: "Color" }]}
              value={null}
              onChange={() => {}}
            />
          </FormControl>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <FormControl fullWidth>
            <MuiText
              variant="body2"
              sx={{
                mb: 1,
                fontWeight: 500,
                color: theme.palette.text.primary,
                fontSize: "0.875rem",
              }}
            >
              Attribute Group
            </MuiText>
            <CustomAutocomplete
              disablePortal
              options={[{ label: "Group A" }, { label: "Group B" }]}
              value={null}
              onChange={() => {}}
            />
          </FormControl>
        </Grid>
      </Grid>

      <Box
        sx={{
          p: 2,
          border: `1px solid ${theme.palette.divider}`,
          borderRadius: "8px",
          background: "#fafafa",
        }}
      >
        <MuiText
          variant="subtitle2"
          sx={{ mb: 2, fontWeight: 600, color: theme.palette.text.primary }}
        >
          Variants
        </MuiText>

        <Grid container spacing={2} alignItems="flex-end">
          {variantFields.map((field) => (
            <Grid item xs={12} sm={6} md={3} key={field.key}>
              <FormControl fullWidth>
                <MuiText
                  variant="body2"
                  sx={{
                    mb: 1,
                    fontWeight: 500,
                    color: theme.palette.text.primary,
                    fontSize: "0.875rem",
                  }}
                >
                  {field.label}
                </MuiText>

                {renderField(
                  field,
                  supplierForm[field.key as keyof SupplierRow],
                  (val: string) =>
                    handleSupplierFormChange(
                      field.key as keyof SupplierRow,
                      val
                    )
                )}
              </FormControl>
            </Grid>
          ))}

          <Grid item xs={12} sm={6} md={3} sx={{ mt: { xs: 2, md: 0 } }}>
            <MuiButton
              variant="contained"
              sx={{
                borderRadius: "6px !important",
                minWidth: 100,
                height: "40px",
                fontWeight: 500,
              }}
              onClick={handleSupplierAdd}
              disabled={!supplierForm.attributes || !supplierForm.value}
            >
              Add
            </MuiButton>
          </Grid>
        </Grid>
      </Box>

      <Box mt={2}>
        {suppliers.map((sup, i) => (
          <Box
            key={i}
            sx={{
              display: "flex",
              gap: 2,
              p: 1,
              border: `1px solid ${theme.palette.divider}`,
              borderRadius: "6px",
              mb: 1,
              background: "#fff",
            }}
          >
            <MuiText variant="body2">
              <strong>{sup.attributes}</strong>: {sup.value}
            </MuiText>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default ItemVariants;
