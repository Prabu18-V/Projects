import React, { useState } from "react";
import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  Grid,
  useTheme,
  IconButton,
  Paper,
  Stack,
} from "@mui/material";
import { MuiButton, MuiText } from "bsoft-base-elements";
import { StyledAutocomplete } from "../../../../utils/lib";
import { FieldConfig } from "../PartyMaster/GeneralPartyInfo";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { RiDeleteBin6Line } from "react-icons/ri";
import CustomTextField from "../../../atoms/ModernComponents/CustomTextField";

type SupplierRow = {
  supplier: string;
  supplierPartNo: string;
  unit: string;
};

interface PurchaseItemProps {
  formData: Record<string, any>;
  handleInputChange: (name: string, value: any) => void;
}

const purchaseFields: FieldConfig[] = [
  { name: "purchaseUom", label: "Purchase UOM", field: "dropdown" },
  { name: "leadTime", label: "Lead Time (Days)", field: "input" },
  { name: "safetyStock", label: "Safety Stock", field: "input" },
  {
    name: "grProcessingTime",
    label: "GR Processing Time (Days)",
    field: "input",
  },
  {
    name: "purchaseRate",
    label: "Purchase Rate",
    field: "input",
  },
  { name: "automaticPO", label: "Automatic PO", field: "checkbox" },
];

const supplierOptions = ["Supplier A", "Supplier B"];
const unitOptions = ["EA", "KG", "LTR"];

const PurchaseItem: React.FC<PurchaseItemProps> = ({
  formData,
  handleInputChange,
}) => {
  const theme = useTheme();

  const headerStyle = {
    mb: 1,
    fontWeight: 500,
    color: theme.palette.text.primary,
    fontSize: "0.875rem",
  };

  const [supplierForm, setSupplierForm] = useState<SupplierRow>({
    supplier: "",
    supplierPartNo: "",
    unit: "",
  });

  const [supplierRows, setSupplierRows] = useState<SupplierRow[]>([]);

  const handleSupplierFormChange = (
    field: keyof SupplierRow,
    value: string
  ) => {
    setSupplierForm({ ...supplierForm, [field]: value });
  };

  const handleSupplierAdd = () => {
    if (
      !supplierForm.supplier ||
      !supplierForm.supplierPartNo ||
      !supplierForm.unit
    )
      return;
    setSupplierRows([...supplierRows, { ...supplierForm }]);
    setSupplierForm({ supplier: "", supplierPartNo: "", unit: "" });
  };

  const handleSupplierDelete = (idx: number) => () => {
    setSupplierRows(supplierRows.filter((_, i) => i !== idx));
  };

  const renderField = (
    { label, type, isRequired, field = "input", options }: FieldConfig,
    value: any,
    onChange: (value: any) => void,
    idx: number
  ) => {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-start",
        }}
      >
        {field === "input" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <CustomTextField
              fullWidth
              type={type || "text"}
              variant="outlined"
              size="small"
              value={value || ""}
              onChange={(e) => onChange(e.target.value)}
            />
          </FormControl>
        )}

        {field === "checkbox" && (
          <FormControlLabel
            control={<Checkbox size="medium" />}
            label={
              <MuiText variant="body2" sx={headerStyle}>
                {label}
              </MuiText>
            }
            sx={{ mt: "1.5rem", ml: 0 }}
          />
        )}

        {field === "dropdown" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <StyledAutocomplete
              disablePortal
              options={options || []}
              value={value || null}
              onChange={(_, newValue) => onChange(newValue || "")}
              renderInput={(params) => (
                <CustomTextField {...params} variant="outlined" size="small" />
              )}
            />
          </FormControl>
        )}

        {field === "picker" && (
          <>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                slotProps={{
                  textField: {
                    fullWidth: true,
                    size: "small",
                    placeholder: "",
                  },
                }}
                format={"MM-DD-YYYY"}
                value={value || null}
                onChange={onChange}
              />
            </LocalizationProvider>
          </>
        )}
      </Box>
    );
  };

  const renderFields = (fields: FieldConfig[]) => (
    <Grid container spacing={2}>
      <Grid container spacing={2} p={3}>
        {/* Main fields */}
        {fields.map((fieldConfig, idx) => (
          <Grid item xs={12} sm={6} md={3} key={fieldConfig.name}>
            {renderField(
              fieldConfig,
              formData[fieldConfig.name],
              (value) => handleInputChange(fieldConfig.name, value),
              idx
            )}
          </Grid>
        ))}
      </Grid>

      <MuiText
        variant="body2"
        sx={{
          m: "12px 0 0 32px",
          fontWeight: 500,
          color: "#3a8484",
          fontSize: "1rem",
        }}
      >
        Foreign Trade Details
      </MuiText>

      <Grid container spacing={2} p={2} pl={4}>
        {[
          { name: "originCountry", label: "Origin Country", field: "dropdown" },
          { name: "tariffNumber", label: "Tariff Number", field: "input" },
        ].map((li) => (
          <Grid item xs={12} sm={6} md={3} key={li.name}>
            <FormControl fullWidth>
              <MuiText variant="body2" sx={headerStyle}>
                {li.label}
              </MuiText>
              <CustomTextField
                fullWidth
                type={"text"}
                variant="outlined"
                size="small"
              />
            </FormControl>
          </Grid>
        ))}
      </Grid>

      {/* Supplier Rows Section */}
      <Grid item xs={12}>
        <Box bgcolor="#fafafa" p={3} borderRadius={1}>
          <Grid container spacing={2} alignItems="flex-end">
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Supplier
                </MuiText>
                <StyledAutocomplete
                  disablePortal
                  options={supplierOptions}
                  value={supplierForm.supplier || null}
                  onChange={(_, val: any) =>
                    handleSupplierFormChange("supplier", val || "")
                  }
                  renderInput={(params) => (
                    <CustomTextField
                      {...params}
                      variant="outlined"
                      size="small"
                    />
                  )}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Supplier Part No.
                </MuiText>
                <CustomTextField
                  fullWidth
                  variant="outlined"
                  size="small"
                  value={supplierForm.supplierPartNo}
                  onChange={(e) =>
                    handleSupplierFormChange("supplierPartNo", e.target.value)
                  }
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Unit
                </MuiText>
                <StyledAutocomplete
                  disablePortal
                  options={unitOptions}
                  value={supplierForm.unit || null}
                  onChange={(_, val: any) =>
                    handleSupplierFormChange("unit", val || "")
                  }
                  renderInput={(params) => (
                    <CustomTextField
                      {...params}
                      variant="outlined"
                      size="small"
                    />
                  )}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3} sx={{ mt: { xs: 2, md: 0 } }}>
              <MuiButton
                variant="contained"
                sx={{
                  borderRadius: "6px !important",
                  minWidth: 100,
                  height: "40px",
                  fontWeight: 500,
                }}
                onClick={handleSupplierAdd}
                disabled={
                  !supplierForm.supplier ||
                  !supplierForm.supplierPartNo ||
                  !supplierForm.unit
                }
              >
                Add
              </MuiButton>
            </Grid>
          </Grid>
          {supplierRows.length > 0 && (
            <Grid container spacing={2} sx={{ mt: 2 }}>
              {supplierRows.map((row, idx) => (
                <Grid item xs={12} key={idx}>
                  <Paper
                    elevation={1}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      p: 1.5,
                      gap: 2,
                      flexWrap: "wrap",
                    }}
                  >
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Supplier:</b> {row.supplier}
                    </MuiText>
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Supplier Part No.:</b> {row.supplierPartNo}
                    </MuiText>
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Unit:</b> {row.unit}
                    </MuiText>
                    <IconButton
                      onClick={handleSupplierDelete(idx)}
                      color="error"
                      size="small"
                      sx={{ ml: "auto" }}
                    >
                      <RiDeleteBin6Line color="red" size={20} />
                    </IconButton>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Grid>
    </Grid>
  );

  return <div>{renderFields(purchaseFields)}</div>;
};

export default PurchaseItem;
