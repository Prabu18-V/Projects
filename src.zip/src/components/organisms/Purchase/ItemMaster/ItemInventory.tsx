import React, { useState } from "react";
import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  Grid,
  useTheme,
  IconButton,
  Paper,
  Stack,
} from "@mui/material";
import { MuiButton, MuiText } from "bsoft-base-elements";
import { StyledAutocomplete } from "../../../../utils/lib";
import { FieldConfig } from "../PartyMaster/GeneralPartyInfo";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { RiDeleteBin6Line } from "react-icons/ri";
import CustomTextField from "../../../atoms/ModernComponents/CustomTextField";

type InventoryAttributeRow = {
  unit: string;
  type: string;
};

interface GeneralItemInfoProps {
  formData: Record<string, any>;
  handleInputChange: (name: string, value: any) => void;
  InventoryMisc: any[];
}

const checkboxFields: FieldConfig[] = [
  {
    name: "allowNegativeStock",
    label: "Allow Negative Stock",
    field: "checkbox",
  },
  { name: "batchManagement", label: "Batch Management", field: "checkbox" },
  {
    name: "applyBatchNumber",
    label: "Apply Batch Number?",
    field: "checkbox",
  },
];

const unitOptions = ["Knitting", "Spinning", "Weaving", "Home Textiles"];
const typeOptions = ["Raw Material", "FG", "SFG", "Unit"];

const ItemInventory: React.FC<GeneralItemInfoProps> = ({
  formData,
  handleInputChange,
  InventoryMisc,
}) => {
  const theme = useTheme();

  const customerGroupFields: FieldConfig[] = [
    { name: "weight", label: "Weight", field: "input" },
    { name: "weightUom", label: "Weight UOM", field: "dropdown" },
    {
      name: "defaultMaterialRequestType",
      label: "Default Material Request Type",
      field: "dropdown",
      options: InventoryMisc?.at(0),
      optionLabel: ["code"],
    },
    {
      name: "valuationMethod",
      label: "Valuation Method",
      field: "dropdown",
      options: InventoryMisc?.at(1),
      optionLabel: ["code"],
    },
    {
      name: "shelfLife",
      label: "Shelf Life",
      field: "input",
    },
    { name: "upperTolerance", label: "Upper Tolerance %", field: "input" },
    { name: "lowerTolerance", label: "Lower Tolerance %", field: "input" },
    {
      name: "batchNumberSeries",
      label: "Batch Number Series",
      field: "input",
    },
    {
      name: "serialNumberSeries",
      label: "Serial Number Series",
      field: "input",
    },
    {
      name: "reorderLevel",
      label: "Re-order Level",
      field: "input",
    },
    {
      name: "reorderQty",
      label: "Re-order Quantity",
      field: "input",
    },
    {
      name: "requestType",
      label: "Request Type",
      field: "dropdown",
      options: InventoryMisc?.at(2),
      optionLabel: ["code"],
    },
  ];

  const headerStyle = {
    mb: 1,
    fontWeight: 500,
    color: theme.palette.text.primary,
    fontSize: "0.875rem",
  };

  const [attrForm, setAttrForm] = useState<InventoryAttributeRow>({
    unit: "",
    type: "",
  });
  const [attrRows, setAttrRows] = useState<InventoryAttributeRow[]>([]);

  const handleAttrChange = (
    field: keyof InventoryAttributeRow,
    value: string
  ) => setAttrForm({ ...attrForm, [field]: value });

  const handleAttrAdd = () => {
    if (!attrForm.unit || !attrForm.type) return;
    setAttrRows([...attrRows, attrForm]);
    setAttrForm({ unit: "", type: "" });
  };

  const handleAttrDelete = (idx: number) => () => {
    setAttrRows(attrRows.filter((_, i) => i !== idx));
  };

  const renderField = (
    {
      label,
      type,
      isRequired,
      field = "input",
      options,
      optionLabel,
    }: FieldConfig,
    value: any,
    onChange: (value: any) => void,
    idx: number
  ) => {
    if (field === "checkbox") return null;
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-start",
        }}
      >
        {field === "input" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <CustomTextField
              fullWidth
              type={type || "text"}
              variant="outlined"
              size="small"
              value={value || ""}
              onChange={(e) => onChange(e.target.value)}
            />
          </FormControl>
        )}

        {field === "dropdown" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <StyledAutocomplete
              disablePortal
              options={options || []}
              value={value || null}
              onChange={(_, newValue) => onChange(newValue || "")}
              getOptionLabel={(option: any) => {
                if (!option) return "";

                if (Array.isArray(optionLabel) && optionLabel.length > 0) {
                  const key1 = optionLabel[0];
                  const key2 = optionLabel[1];

                  if (key2) {
                    const val1 = option[key1] ?? "";
                    const val2 = option[key2] ?? "";
                    return val2 ? `${val1} - ${val2}` : val1;
                  }

                  return option[key1] ?? "";
                }

                return typeof option === "string" ? option : "";
              }}
              isOptionEqualToValue={(opt, val) => {
                if (Array.isArray(optionLabel) && optionLabel.length > 0) {
                  const key = optionLabel[0];
                  return (opt as any)[key] === (val as any)[key];
                }
                return opt === val;
              }}
              renderInput={(params) => (
                <CustomTextField {...params} variant="outlined" size="small" />
              )}
            />
          </FormControl>
        )}

        {field === "picker" && (
          <>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                slotProps={{
                  textField: {
                    fullWidth: true,
                    size: "small",
                    placeholder: "",
                  },
                }}
                format={"MM-DD-YYYY"}
                value={value || null}
                onChange={onChange}
              />
            </LocalizationProvider>
          </>
        )}
      </Box>
    );
  };

  const renderCheckboxFields = (
    fields: FieldConfig[],
    formData: Record<string, any>,
    handleInputChange: (name: string, value: any) => void
  ) => (
    <Box sx={{ mt: 1 }}>
      <Stack direction="row" spacing={3}>
        {fields.map((f) => (
          <FormControlLabel
            key={f.name}
            control={
              <Checkbox
                checked={formData[f.name] || false}
                onChange={(e) => handleInputChange(f.name, e.target.checked)}
                size="medium"
              />
            }
            label={
              <MuiText
                variant="body2"
                sx={{
                  mb: 0,
                  fontWeight: 500,
                  color: theme.palette.text.primary,
                  fontSize: "0.875rem",
                }}
              >
                {f.label}
              </MuiText>
            }
            sx={{ m: 0, mr: 3 }}
          />
        ))}
      </Stack>
    </Box>
  );

  const renderFields = (fields: FieldConfig[]) => (
    <Grid container spacing={2}>
      {fields.map((fieldConfig, idx) => (
        <Grid item xs={12} sm={6} md={3} key={fieldConfig.name}>
          {renderField(
            fieldConfig,
            formData[fieldConfig.name],
            (value) => handleInputChange(fieldConfig.name, value),
            idx
          )}
        </Grid>
      ))}

      <Grid item xs={12} sm={6} md={12}>
        {renderCheckboxFields(checkboxFields, formData, handleInputChange)}
      </Grid>

      <MuiText
        variant="body2"
        sx={{
          m: "12px 0 0 18px",
          fontWeight: 500,
          color: "#3a8484",
          fontSize: "1rem",
        }}
      >
        Manufacturing
      </MuiText>

      <Grid item xs={12}>
        <Box bgcolor="#fafafa" p={3} borderRadius={1}>
          <Grid container spacing={2} alignItems="flex-end">
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Unit
                </MuiText>
                <StyledAutocomplete
                  disablePortal
                  options={unitOptions}
                  value={attrForm.unit || null}
                  onChange={(_, val: any) =>
                    handleAttrChange("unit", val || "")
                  }
                  renderInput={(params) => (
                    <CustomTextField
                      {...params}
                      variant="outlined"
                      size="small"
                    />
                  )}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Type
                </MuiText>
                <StyledAutocomplete
                  disablePortal
                  options={InventoryMisc?.at(3)}
                  getOptionLabel={(option: any) => `${option?.code}`}
                  value={attrForm.type || null}
                  onChange={(_, val: any) =>
                    handleAttrChange("type", val || "")
                  }
                  renderInput={(params) => (
                    <CustomTextField
                      {...params}
                      variant="outlined"
                      size="small"
                    />
                  )}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3} sx={{ mt: { xs: 2, md: 0 } }}>
              <MuiButton
                variant="contained"
                sx={{
                  borderRadius: "6px !important",
                  minWidth: 100,
                  height: "40px",
                  fontWeight: 500,
                }}
                onClick={handleAttrAdd}
                disabled={!attrForm.unit || !attrForm.type}
              >
                Add
              </MuiButton>
            </Grid>
          </Grid>
          {attrRows.length > 0 && (
            <Grid container spacing={2} sx={{ mt: 2 }}>
              {attrRows.map((row, idx) => (
                <Grid item xs={12} key={idx}>
                  <Paper
                    elevation={1}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      p: 1.5,
                      gap: 2,
                      flexWrap: "wrap",
                    }}
                  >
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Unit:</b> {row.unit}
                    </MuiText>
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Type:</b> {row.type}
                    </MuiText>
                    <IconButton
                      onClick={handleAttrDelete(idx)}
                      color="error"
                      size="small"
                      sx={{ ml: "auto" }}
                    >
                      <RiDeleteBin6Line color="red" size={20} />
                    </IconButton>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Grid>
    </Grid>
  );

  return <div>{renderFields(customerGroupFields)}</div>;
};

export default ItemInventory;
