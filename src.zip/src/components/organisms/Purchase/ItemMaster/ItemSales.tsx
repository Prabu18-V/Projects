import React from "react";
import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  Grid,
  TextField,
  useTheme,
  Stack,
} from "@mui/material";
import { MuiText } from "bsoft-base-elements";
import { StyledAutocomplete } from "../../../../utils/lib";
import { FieldConfig } from "../PartyMaster/GeneralPartyInfo";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import CustomTextField from "../../../atoms/ModernComponents/CustomTextField";

interface GeneralItemInfoProps {
  formData: Record<string, any>;
  handleInputChange: (name: string, value: any) => void;
}

const customerGroupFields: FieldConfig[] = [
  {
    name: "salesUOM",
    label: "Sales UOM",
    field: "input",
  },
  {
    name: "maximumDiscount",
    label: "Maximum Discount",
    field: "input",
  },
  {
    name: "deliveringPlant",
    label: "Delivering Plant",
    field: "input",
  },
  {
    name: "distributionChannel",
    label: "Distribution Channel",
    field: "input",
  },
  {
    name: "salesOrganization",
    label: "Sales Organization",
    field: "dropdown",
  },
  {
    name: "salesStatus",
    label: "Sales Status (X-plant)",
    field: "dropdown",
  },
  {
    name: "minimumOrderQty",
    label: "Minimum Order Qty",
    field: "input",
  },
  {
    name: "materialPricingGrp",
    label: "Material Pricing Grp",
    field: "dropdown",
  },
  {
    name: "taxClassification",
    label: "Tax Classification",
    field: "input",
  },
  {
    name: "acctAssignmentGroup",
    label: "Acct Assignment Group",
    field: "dropdown",
  },
  {
    name: "loadingGroup",
    label: "Loading Group",
    field: "dropdown",
  },
  {
    name: "transportationGroup",
    label: "Transportation Group",
    field: "dropdown",
  },
  {
    name: "materialFreightGrp",
    label: "Material Freight Grp",
    field: "dropdown",
  },
  {
    name: "shippingConditions",
    label: "Shipping Conditions",
    field: "input",
  },
];

const checkboxFields: FieldConfig[] = [
  {
    name: "commissionAllowed",
    label: "Commission Allowed",
    field: "checkbox",
  },
  {
    name: "isCertificateRequired",
    label: "Is Certificate Required from Supplier?",
    field: "checkbox",
  },
];

const ItemSales: React.FC<GeneralItemInfoProps> = ({
  formData,
  handleInputChange,
}) => {
  const theme = useTheme();

  const headerStyle = {
    mb: 1,
    fontWeight: 500,
    color: theme.palette.text.primary,
    fontSize: "0.875rem",
  };

  const renderField = (
    { label, type, isRequired, field = "input", options }: FieldConfig,
    value: any,
    onChange: (value: any) => void,
    idx: number
  ) => {
    if (field === "checkbox") return null;
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-start",
        }}
      >
        {field === "input" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <CustomTextField
              fullWidth
              type={type || "text"}
              variant="outlined"
              size="small"
              value={value || ""}
              onChange={(e) => onChange(e.target.value)}
            />
          </FormControl>
        )}

        {field === "dropdown" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <StyledAutocomplete
              disablePortal
              options={options || []}
              value={value || null}
              onChange={(_, newValue) => onChange(newValue || "")}
              renderInput={(params) => (
                <CustomTextField {...params} variant="outlined" size="small" />
              )}
            />
          </FormControl>
        )}

        {field === "picker" && (
          <>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                slotProps={{
                  textField: {
                    fullWidth: true,
                    size: "small",
                    placeholder: "",
                  },
                }}
                format={"MM-DD-YYYY"}
                value={value || null}
                onChange={onChange}
              />
            </LocalizationProvider>
          </>
        )}
      </Box>
    );
  };

  const renderCheckboxFields = (
    fields: FieldConfig[],
    formData: Record<string, any>,
    handleInputChange: (name: string, value: any) => void
  ) => (
    <Box sx={{ mt: 1 }}>
      <Stack direction="row" spacing={3}>
        {fields.map((f) => (
          <FormControlLabel
            key={f.name}
            control={
              <Checkbox
                checked={formData[f.name] || false}
                onChange={(e) => handleInputChange(f.name, e.target.checked)}
                size="medium"
              />
            }
            label={
              <MuiText
                variant="body2"
                sx={{
                  mb: 0,
                  fontWeight: 500,
                  color: theme.palette.text.primary,
                  fontSize: "0.875rem",
                }}
              >
                {f.label}
              </MuiText>
            }
            sx={{ m: 0, mr: 3 }}
          />
        ))}
      </Stack>
    </Box>
  );

  const renderFields = (fields: FieldConfig[]) => (
    <Grid container spacing={2}>
      {fields.map((fieldConfig, idx) => (
        <Grid item xs={12} sm={6} md={3} key={fieldConfig.name}>
          {renderField(
            fieldConfig,
            formData[fieldConfig.name],
            (value) => handleInputChange(fieldConfig.name, value),
            idx
          )}
        </Grid>
      ))}

      <Grid item xs={12}>
        {renderCheckboxFields(checkboxFields, formData, handleInputChange)}
      </Grid>
    </Grid>
  );

  return <div>{renderFields(customerGroupFields)}</div>;
};

export default ItemSales;
