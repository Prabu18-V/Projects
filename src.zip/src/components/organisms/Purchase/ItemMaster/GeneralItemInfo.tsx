import React, { useState } from "react";
import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  Grid,
  TextField,
  useTheme,
  IconButton,
  Paper,
  Stack,
} from "@mui/material";
import { MuiButton, MuiText } from "bsoft-base-elements";
import { StyledAutocomplete } from "../../../../utils/lib";
import { FieldConfig } from "../PartyMaster/GeneralPartyInfo";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { RiDeleteBin6Line } from "react-icons/ri";
import CustomTextField from "../../../atoms/ModernComponents/CustomTextField";

type UOMRow = {
  baseUom: string;
  convUom: string;
  convRate: string;
};

interface GeneralItemInfoProps {
  formData: Record<string, any>;
  handleInputChange: (name: string, value: any) => void;
  GeneralInfoMisc: any[];
}

const checkboxFields: FieldConfig[] = [
  { name: "isStockItem", label: "Is Stock Item?", field: "checkbox" },
  { name: "maintainStock", label: "Maintain Stock?", field: "checkbox" },
  { name: "hasVariants", label: "Has Variants?", field: "checkbox" },
];

const GeneralItemInfo: React.FC<GeneralItemInfoProps> = ({
  formData,
  handleInputChange,
  GeneralInfoMisc,
}) => {
  const theme = useTheme();

  const customerGroupFields: FieldConfig[] = [
    { name: "itemCode", label: "Item Code", field: "input" },
    { name: "itemName", label: "Item Name", field: "input" },
    {
      name: "hsnCode",
      label: "HSN Code",
      field: "dropdown",
      options: GeneralInfoMisc?.at(2),
      optionLabel: ["hsnCode", "hsnDescription"],
    },
    {
      name: "itemGroup",
      label: "Item Group",
      field: "dropdown",
      options: GeneralInfoMisc?.at(3),
      optionLabel: ["itemGroupName"],
    },
    {
      name: "itemCategory",
      label: "Item Category",
      field: "dropdown",
      options: GeneralInfoMisc?.at(4),
      optionLabel: ["itemCategoryName"],
    },
    { name: "defaultUom", label: "Default UOM", field: "dropdown" },
    {
      name: "itemClassification",
      label: "Item Classification",
      field: "dropdown",
      options: GeneralInfoMisc?.at(0),
      optionLabel: ["code"],
    },
    { name: "description", label: "Description", field: "input" },
    { name: "validFrom", label: "Valid From", field: "picker" },
    {
      name: "materialStatus",
      label: "X-plant Material Status",
      field: "dropdown",
      options: GeneralInfoMisc?.at(1),
      optionLabel: ["code"],
    },
    {
      name: "unit",
      label: "Unit",
      field: "dropdown",
    },
    {
      name: "department",
      label: "Department",
      field: "dropdown",
    },
  ];

  const headerStyle = {
    mb: 1,
    fontWeight: 500,
    color: theme.palette.text.primary,
    fontSize: "0.875rem",
  };

  const [form, setForm] = useState<UOMRow>({
    baseUom: "",
    convUom: "",
    convRate: "",
  });

  const [rows, setRows] = useState<UOMRow[]>([]);

  const handleChange =
    (field: keyof UOMRow) => (e: React.ChangeEvent<HTMLInputElement>) => {
      setForm({ ...form, [field]: e.target.value });
    };

  const handleAdd = () => {
    if (!form.baseUom || !form.convUom || !form.convRate) return;
    setRows([...rows, { ...form }]);
    setForm({ baseUom: "", convUom: "", convRate: "" });
  };

  const handleDelete = (idx: number) => () => {
    setRows(rows.filter((_, i) => i !== idx));
  };

  const renderField = (
    {
      name,
      label,
      type,
      isRequired,
      field = "input",
      options,
      optionLabel,
    }: FieldConfig,
    value: any,
    onChange: (value: any) => void,
    idx: number
  ) => {
    if (field === "checkbox") return null;

    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-start",
        }}
      >
        {field === "input" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <CustomTextField
              fullWidth
              type={type || "text"}
              variant="outlined"
              size="small"
              value={value || ""}
              placeholder={name === "itemCode" ? "Eg: RAW-COT-01" : ""}
              onChange={(e) => onChange(e.target.value)}
            />
          </FormControl>
        )}

        {field === "dropdown" && (
          <FormControl fullWidth>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <StyledAutocomplete
              disablePortal
              options={options || []}
              value={value || null}
              onChange={(_, newValue) => onChange(newValue || "")}
              getOptionLabel={(option: any) => {
                if (!option) return "";

                if (Array.isArray(optionLabel) && optionLabel.length > 0) {
                  const key1 = optionLabel[0];
                  const key2 = optionLabel[1];

                  if (key2) {
                    const val1 = option[key1] ?? "";
                    const val2 = option[key2] ?? "";
                    return val2 ? `${val1} - ${val2}` : val1;
                  }

                  return option[key1] ?? "";
                }

                return typeof option === "string" ? option : "";
              }}
              isOptionEqualToValue={(opt, val) => {
                if (Array.isArray(optionLabel) && optionLabel.length > 0) {
                  const key = optionLabel[0];
                  return (opt as any)[key] === (val as any)[key];
                }
                return opt === val;
              }}
              renderInput={(params) => (
                <CustomTextField {...params} variant="outlined" size="small" />
              )}
            />
          </FormControl>
        )}

        {field === "picker" && (
          <>
            <MuiText variant="body2" sx={headerStyle}>
              {label}
              {isRequired && (
                <MuiText
                  component="span"
                  sx={{
                    color: "error.main",
                    ml: 0.5,
                    fontSize: "inherit !important",
                  }}
                >
                  *
                </MuiText>
              )}
            </MuiText>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                slotProps={{
                  textField: {
                    fullWidth: true,
                    size: "small",
                    placeholder: "",
                  },
                }}
                format={"MM-DD-YYYY"}
                value={value || null}
                onChange={onChange}
              />
            </LocalizationProvider>
          </>
        )}
      </Box>
    );
  };

  const renderCheckboxFields = (
    fields: FieldConfig[],
    formData: Record<string, any>,
    handleInputChange: (name: string, value: any) => void
  ) => (
    <Box sx={{ mt: 1 }}>
      <Stack direction="row" spacing={3}>
        {fields.map((f) => (
          <FormControlLabel
            key={f.name}
            control={
              <Checkbox
                checked={formData[f.name] || false}
                onChange={(e) => handleInputChange(f.name, e.target.checked)}
                size="medium"
              />
            }
            label={
              <MuiText
                variant="body2"
                sx={{
                  fontSize: "0.875rem",
                  fontWeight: 500,
                  whiteSpace: "nowrap",
                }}
              >
                {f.label}
              </MuiText>
            }
            sx={{ m: 0, mr: 3 }}
          />
        ))}
      </Stack>
    </Box>
  );

  const renderFields = (fields: FieldConfig[]) => (
    <Grid container spacing={2}>
      {/* Main fields */}
      {fields.map((fieldConfig, idx) => (
        <Grid item xs={12} sm={6} md={3} key={fieldConfig.name}>
          {renderField(
            fieldConfig,
            formData[fieldConfig.name],
            (value) => handleInputChange(fieldConfig.name, value),
            idx
          )}
        </Grid>
      ))}

      {/* Inline Checkboxes */}
      <Grid item xs={12}>
        {renderCheckboxFields(checkboxFields, formData, handleInputChange)}
      </Grid>

      <Grid item xs={12}>
        <Box
          bgcolor="#fafafa"
          p={3}
          borderRadius={1}
          sx={{
            "& .MuiOutlinedInput-root": {
              height: "40px",
              fontSize: "0.875rem",
              background: "#fff",
            },
          }}
        >
          <Grid container spacing={2} alignItems="flex-end">
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Base UOM
                </MuiText>
                <CustomTextField
                  fullWidth
                  variant="outlined"
                  size="small"
                  value={form.baseUom}
                  onChange={handleChange("baseUom")}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Conversion UOM
                </MuiText>
                <StyledAutocomplete
                  disablePortal
                  options={[]}
                  renderInput={(params) => (
                    <CustomTextField
                      {...params}
                      variant="outlined"
                      size="small"
                    />
                  )}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <MuiText variant="body2" sx={headerStyle}>
                  Conversion Rate
                </MuiText>
                <CustomTextField
                  type="number"
                  fullWidth
                  variant="outlined"
                  size="small"
                  value={form.convRate}
                  onChange={handleChange("convRate")}
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={3} sx={{ mt: { xs: 2, md: 0 } }}>
              <MuiButton
                variant="contained"
                sx={{
                  borderRadius: "6px !important",
                  minWidth: 100,
                  height: "40px",
                  fontWeight: 500,
                }}
                onClick={handleAdd}
                disabled={!form.baseUom || !form.convUom || !form.convRate}
              >
                Add
              </MuiButton>
            </Grid>
          </Grid>
          {rows.length > 0 && (
            <Grid container spacing={2} sx={{ mt: 2 }}>
              {rows.map((row, idx) => (
                <Grid item xs={12} key={idx}>
                  <Paper
                    elevation={1}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      p: 1.5,
                      gap: 2,
                      flexWrap: "wrap",
                    }}
                  >
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Base UOM:</b> {row.baseUom}
                    </MuiText>
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Conversion UOM:</b> {row.convUom}
                    </MuiText>
                    <MuiText
                      sx={{
                        flex: "1 1 180px",
                        minWidth: 120,
                        fontSize: "0.9rem",
                      }}
                    >
                      <b>Rate:</b> {row.convRate}
                    </MuiText>
                    <IconButton
                      onClick={handleDelete(idx)}
                      color="error"
                      size="small"
                      sx={{ ml: "auto" }}
                    >
                      <RiDeleteBin6Line color="red" size={20} />
                    </IconButton>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Grid>
    </Grid>
  );

  return <div>{renderFields(customerGroupFields)}</div>;
};

export default GeneralItemInfo;
