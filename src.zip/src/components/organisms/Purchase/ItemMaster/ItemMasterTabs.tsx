import React, { useEffect } from "react";
import NavTabs from "../../../atoms/ModernComponents/NavTabs";
import { Box, Tab, Tabs } from "@mui/material";
import { TabContext, TabPanel } from "@mui/lab";
import { tabStyles } from "../PartyMaster/PartyTabs";
import GeneralItemInfo from "./GeneralItemInfo";
import PurchaseItem from "./PurchaseItem";
import ItemInventory from "./ItemInventory";
import ItemQuality from "./ItemQuality";
import ItemSales from "./ItemSales";
import ItemVariants from "./ItemVariants";
import { useDataFetchHook } from "../../../../hooks/useDataFetchHook";
import InventoryConfig from "../../../../utils/inventory.api.json";

interface ItemState {
  formData: Record<string, any>;
}

function ItemMasterTabs() {
  const [value, setValue] = React.useState("1");
  const [partyState, setPartyState] = React.useState<ItemState>({
    formData: {},
  });

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const handleInputChange = (name: string, value: any) => {
    setPartyState((prev) => ({
      ...prev,
      formData: { ...prev.formData, [name]: value },
    }));
  };

  useEffect(() => {
    if (!partyState?.formData.hasVariants && value === "6") {
      setValue("1");
    }
  }, [partyState?.formData.hasVariants, value]);

  // ---------------- Dropdown API Calls ----------------

  const types = [
    "ItemClassification",
    "MaterialStatus",
    "CertificateType",
    "ManufactureType",
    "MaterialRequestType",
    "ValuationMethod",
    "RequestType",
    "VariantBasedOn",
    "AttributeName",
    "AttributeGroup",
  ];

  const dataFetches = types.reduce((acc, type) => {
    acc[`${type}Data`] = useDataFetchHook(
      InventoryConfig.InventoryMisc.endpoint.replace("{type}", type),
      InventoryConfig.InventoryMisc.method,
      "inventory"
    ).data;
    return acc;
  }, {} as Record<string, any>);

  const { data: HsnCodeData } = useDataFetchHook(
    InventoryConfig.HsnCode.GetHsnCodeByName.endpoint,
    InventoryConfig.HsnCode.GetHsnCodeByName.method,
    "inventory"
  );

  const { data: ItemGroupData } = useDataFetchHook(
    InventoryConfig.ItemGroup.GetByGroup.endpoint,
    InventoryConfig.ItemGroup.GetByGroup.method,
    "inventory"
  );

  const { data: ItemCategoryData } = useDataFetchHook(
    InventoryConfig.ItemCategory.GetByCategory.endpoint,
    InventoryConfig.ItemCategory.GetByCategory.method,
    "inventory"
  );

  const {
    ItemClassificationData,
    MaterialStatusData,
    CertificateTypeData,
    ManufactureTypeData,
    MaterialRequestTypeData,
    ValuationMethodData,
    RequestTypeData,
    VariantBasedOnData,
    AttributeNameData,
    AttributeGroupData,
  } = dataFetches;

  // -------------------------------

  const GeneralInfoMisc = [
    ItemClassificationData,
    MaterialStatusData,
    HsnCodeData,
    ItemGroupData,
    ItemCategoryData,
  ];

  const InventoryMisc = [
    MaterialRequestTypeData,
    ValuationMethodData,
    RequestTypeData,
    ManufactureTypeData
  ];

  const VariantMisc = [VariantBasedOnData, AttributeGroupData];
  const QualityMisc = [];

  return (
    <NavTabs>
      <TabContext value={value}>
        <Tabs
          value={value}
          onChange={handleChange}
          textColor="primary"
          indicatorColor="primary"
          aria-label="primary tabs example"
        >
          <Tab value="1" label="General Details" />
          <Tab value="2" label="Purchase" />
          <Tab value="4" label="Inventory" />
          <Tab value="5" label="Quality" />
          {partyState?.formData.hasVariants && (
            <Tab value="6" label="Variants/Attributes" />
          )}
          <Tab value="7" label="Sale" />
        </Tabs>

        <TabPanel value="1">
          <Box sx={tabStyles}>
            <GeneralItemInfo
              formData={partyState.formData}
              handleInputChange={handleInputChange}
              GeneralInfoMisc={GeneralInfoMisc}
            />
          </Box>
        </TabPanel>
        <TabPanel value="2">
          <Box sx={tabStyles}>
            <PurchaseItem
              formData={partyState.formData}
              handleInputChange={handleInputChange}
            />
          </Box>
        </TabPanel>
        <TabPanel value="4">
          <Box sx={tabStyles}>
            <ItemInventory
              formData={partyState.formData}
              handleInputChange={handleInputChange}
              InventoryMisc={InventoryMisc}
            />
          </Box>
        </TabPanel>
        <TabPanel value="5">
          <Box sx={tabStyles}>
            <ItemQuality
              formData={partyState.formData}
              handleInputChange={handleInputChange}
              CertificateTypeData={CertificateTypeData}
            />
          </Box>
        </TabPanel>
        {partyState?.formData.hasVariants && (
          <TabPanel value="6">
            <Box sx={tabStyles}>
              <ItemVariants VariantMisc={VariantMisc} />
            </Box>
          </TabPanel>
        )}
        <TabPanel value="7">
          <Box sx={tabStyles}>
            <ItemSales
              formData={partyState.formData}
              handleInputChange={handleInputChange}
            />
          </Box>
        </TabPanel>
      </TabContext>
    </NavTabs>
  );
}

export default ItemMasterTabs;
