"use client";

import React, { useState } from "react";
import { Box } from "@mui/material";
import NoDataFound from "../../../molecules/AdminLayout/NoDataFound";
import { MuiTable } from "bsoft-base-elements";
import { useRouter, useSearchParams } from "next/navigation";
import IndentApproval from "./IndentApproval";

export default function ApprovalPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const value = searchParams.get("value");
  const id = searchParams.get("id");

  const [countryData] = useState<any[]>([
    {
      id: 1,
      indentNumber: "124578",
      indentDate: "14-03-2025",
      indentType: "Consumable",
      unit: "Knitting",
      department: "Mechanical",
      raisedBy: "Jabaraj Michael",
      purpose: "-",
    },
    {
      id: 2,
      indentNumber: "124579",
      indentDate: "15-03-2025",
      indentType: "Consumable",
      unit: "Knitting",
      department: "Electrical",
      raisedBy: "John Doe",
      purpose: "Machine Repair",
    },
  ]);

  const columns = [
    {
      field: "indentNumber",
      headerName: "Indent Number",
      flex: 1,
      minWidth: 150,
    },
    { field: "indentDate", headerName: "Indent Date", flex: 2 },
    { field: "indentType", headerName: "Indent Type", flex: 1, minWidth: 150 },
    { field: "unit", headerName: "Unit/Plant", flex: 2, minWidth: 150 },
    { field: "department", headerName: "Department", flex: 2, minWidth: 150 },
    { field: "raisedBy", headerName: "Raised By", flex: 2, minWidth: 150 },
    { field: "purpose", headerName: "Purpose", flex: 2, minWidth: 150 },
  ];

  const handleRowClick = (params: any) => {
    router.push(`/purchase/approval?value=indent&id=${params.row.id}`);
  };

  if (value === "indent" && id) {
    return <IndentApproval />;
  }

  return (
    <Box
      sx={{ width: "100%", my: 2, height: 700 }}
      className="main-table content-wrapper"
    >
      <MuiTable
        rows={countryData}
        columns={columns}
        paginationMode="server"
        initialState={{
          pagination: {
            paginationModel: { pageSize: 15 },
          },
        }}
        rowCount={countryData.length}
        rowHeight={40}
        columnHeaderHeight={40}
        pageSizeOptions={[15, 30, 50]}
        disableRowSelectionOnClick
        onRowClick={handleRowClick}
        slots={{
          noRowsOverlay: () => <NoDataFound />,
        }}
      />
    </Box>
  );
}
