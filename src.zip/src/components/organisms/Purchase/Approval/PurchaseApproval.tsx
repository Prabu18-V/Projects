"use client";

import React from "react";
import IndentApprovalList from "./IndentApprovalList";
import { StyledAutocomplete } from "../../../../utils/lib";
import CustomTextField from "../../../atoms/ModernComponents/CustomTextField";
import { Grid2 } from "@mui/material";

const PurchaseApproval = () => {
  const approvalOptions = [
    { label: "Indent Approval", value: "indent" },
    { label: "Purchase Order Approval", value: "po" },
    { label: "Vendor Approval", value: "vendor" },
    { label: "Budget Approval", value: "budget" },
  ];

  return (
    <>
      <Grid2 container mb={2}>
        <Grid2 size={3}>
          <StyledAutocomplete
            disablePortal
            options={approvalOptions || []}
            renderInput={(params) => (
              <CustomTextField {...params} variant="outlined" size="small" />
            )}
          />
        </Grid2>
      </Grid2>
      <IndentApprovalList />
    </>
  );
};

export default PurchaseApproval;
